COMMAND👇

rm -rf DECOMPILE

git clone https://github.com/INFINITY-999/DECOMPILE

cd DECOMPILE

python dec.py
