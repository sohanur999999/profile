## COMMAND :

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=FF2C10&background=31FF9400&width=435&lines=Random+FB+id+Cloning+Tool+Enjoy+Guys%F0%9F%A4%9F)](https://git.io/typing-svg)

* `pkg update && pkg upgrade`

* `pkg install python`

* `pkg install git`

* `pip install requests`

* `pip install mechanize`

* `pip install futures`

* `pip install rich`

* `pip install bs4`

* `rm -rf 3K-SPECIAL`

* `git clone https://github.com/MUMIT-404-CYBER/3K-SPECIAL.git`

* `cd 3K-SPECIAL`

* `python 3K-GIFT.py`


___This Tool is Free Enjoy Dear User.___</br>
