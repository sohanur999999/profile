# Ok-idr-Script-Gift
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=611FF7&width=435&lines=Assalamu+Alaikum%F0%9F%8C%BA;Script+For+Gift%F0%9F%92%9A;Follow+My+GitHub%F0%9F%A5%B0;Thank+You+Everyone%E2%9D%A4%EF%B8%8F)](https://git.io/typing-svg)
![Picsart_23-04-01_14-44-14-074](https://user-images.githubusercontent.com/106426526/229276697-e3992f16-741a-4a10-88af-3dbda4c6e201.png)
